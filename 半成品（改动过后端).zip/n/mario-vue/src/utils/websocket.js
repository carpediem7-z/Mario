let ws = null
let messageHandlers = []

export const connectWebSocket = (handlers) => {
  const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:'
  const wsUrl = `${protocol}//${window.location.host}/ws/mario` // 根据实际服务器地址修改
  console.log('Connecting to WebSocket:', wsUrl)
  
  ws = new WebSocket(wsUrl)
  
  ws.onopen = () => {
    console.log('WebSocket connected')
    if (handlers.onOpen) handlers.onOpen()
  }
  
  ws.onclose = () => {
    console.log('WebSocket disconnected')
    if (handlers.onClose) handlers.onClose()
  }
  
  ws.onerror = (error) => {
    console.error('WebSocket error:', error)
  }
  
  ws.onmessage = (event) => {
    try {
      const message = JSON.parse(event.data)
      console.log('Received WebSocket message:', message)
      if (message.type === 'gameState' && message.data) {
        console.log('Game state data:', message.data)
      }
      if (handlers.onMessage) handlers.onMessage(message)
      
      // 调用所有注册的消息处理器
      messageHandlers.forEach(handler => handler(message))
    } catch (error) {
      console.error('Failed to parse WebSocket message:', error)
    }
  }
}

export const disconnectWebSocket = () => {
  if (ws) {
    ws.close()
    ws = null
  }
}

export const sendMessage = (message) => {
  if (ws && ws.readyState === WebSocket.OPEN) {
    console.log('Sending WebSocket message:', message)
    ws.send(JSON.stringify(message))
  } else {
    console.warn('WebSocket is not connected')
  }
}

export const addMessageHandler = (handler) => {
  messageHandlers.push(handler)
}

export const removeMessageHandler = (handler) => {
  messageHandlers = messageHandlers.filter(h => h !== handler)
}