const API_BASE = '/api'

export const getRooms = async () => {
  const response = await fetch(`${API_BASE}/game/rooms`)
  return response.json()
}

export const joinRoom = async (roomId, playerName, sessionId) => {
  const response = await fetch(`${API_BASE}/game/room/${roomId}/join`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({ playerName, sessionId })
  })
  return response.json()
}

export const leaveRoom = async (roomId, playerId) => {
  const response = await fetch(`${API_BASE}/game/room/${roomId}/leave`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({ playerId })
  })
  return response.json()
}

export const getPlayerInfo = async (playerId) => {
  const response = await fetch(`${API_BASE}/player/${playerId}`)
  return response.json()
}

export const changeRole = async (playerId, role) => {
  const response = await fetch(`${API_BASE}/player/${playerId}/role`, {
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({ role })
  })
  return response.json()
}