/**
 * 多人游戏UI控制器
 */
class UIController {
    constructor() {
        this.currentView = null;
        this.init();
    }

    init() {
        this.initUIEvents();
        this.initDynamicUI();
        this.loadSettings();
        console.log('UI控制器初始化完成');
    }

    initUIEvents() {
        // 控制方式切换
        const controlModeSelect = document.getElementById('control-mode');
        if (controlModeSelect) {
            controlModeSelect.addEventListener('change', (e) => {
                this.saveSetting('control_mode', e.target.value);
                if (window.gameControls) {
                    window.gameControls.updateControlMode(e.target.value);
                }
            });
        }

        // 角色选择
        const playerRoleSelect = document.getElementById('player-role');
        if (playerRoleSelect) {
            playerRoleSelect.addEventListener('change', (e) => {
                this.saveSetting('player_role', e.target.value);
                if (window.gameApp && window.gameApp.player) {
                    window.gameApp.player.role = e.target.value;
                }
            });
        }

        // 音量控制
        const volumeSlider = document.getElementById('volume-slider');
        if (volumeSlider) {
            volumeSlider.addEventListener('input', (e) => {
                this.saveSetting('volume', e.target.value);
                this.updateVolume(e.target.value);
            });
        }

        // 聊天相关
        const chatToggleBtn = document.getElementById('btn-chat-toggle');
        if (chatToggleBtn) {
            chatToggleBtn.addEventListener('click', () => {
                this.toggleChatPanel();
            });
        }

        const sendBtn = document.getElementById('btn-send');
        const chatInput = document.getElementById('chat-input');
        if (sendBtn && chatInput) {
            sendBtn.addEventListener('click', () => this.sendChatMessage());
            chatInput.addEventListener('keypress', (e) => {
                if (e.key === 'Enter') this.sendChatMessage();
            });
        }

        // 房间相关
const refreshRoomsBtn = document.getElementById('btn-refresh-rooms');
const createRoomBtn = document.getElementById('btn-create-room');

if (refreshRoomsBtn) {
    refreshRoomsBtn.addEventListener('click', () => {
        if (window.gameApp) window.gameApp.loadRooms();
        this.showNotification('房间列表已刷新', 'info');
    });
}

if (createRoomBtn) {
    createRoomBtn.addEventListener('click', () => {
        this.showCreateRoomModal();
    });
}

// 绑定创建房间模态框的按钮
document.addEventListener('click', (e) => {
    if (e.target.id === 'btn-create-room-confirm') {
        this.createRoom();
    } else if (e.target.id === 'btn-create-room-cancel') {
        this.hideCreateRoomModal();
    }
});

// 或者直接在HTML中添加事件监听
setTimeout(() => {
    const createRoomConfirm = document.getElementById('btn-create-room-confirm');
    const createRoomCancel = document.getElementById('btn-create-room-cancel');
    
    if (createRoomConfirm) {
        createRoomConfirm.addEventListener('click', () => this.createRoom());
    }
    
    if (createRoomCancel) {
        createRoomCancel.addEventListener('click', () => this.hideCreateRoomModal());
    }
}, 1000);

        // 游戏控制按钮
        const pauseBtn = document.getElementById('btn-pause');
        const resumeBtn = document.getElementById('btn-resume');
        const changeRoomBtn = document.getElementById('btn-change-room');
        const backMenuBtn = document.getElementById('btn-back-menu');
        
        if (pauseBtn) pauseBtn.addEventListener('click', () => {
            if (window.gameApp) window.gameApp.togglePause();
        });
        
        if (resumeBtn) resumeBtn.addEventListener('click', () => {
            if (window.gameApp) window.gameApp.togglePause();
        });
        
        if (changeRoomBtn) changeRoomBtn.addEventListener('click', () => {
            if (window.gameApp) window.gameApp.backToMenu();
        });
        
        if (backMenuBtn) backMenuBtn.addEventListener('click', () => {
            if (window.gameApp) window.gameApp.backToMenu();
        });

        // 登录相关
        const loginBtn = document.getElementById('btn-login');
        const guestBtn = document.getElementById('btn-guest');
        const usernameInput = document.getElementById('username');
        
        if (loginBtn) {
            loginBtn.addEventListener('click', () => {
                if (window.gameApp) window.gameApp.handleLogin();
            });
        }
        
        if (guestBtn) {
            guestBtn.addEventListener('click', () => {
                if (window.gameApp) window.gameApp.handleGuestLogin();
            });
        }
        
        if (usernameInput) {
            usernameInput.addEventListener('keypress', (e) => {
                if (e.key === 'Enter' && loginBtn) loginBtn.click();
            });
        }

        console.log('UI事件绑定完成');
    }

    initDynamicUI() {
        this.renderHearts(3);
        this.updateScore(0);
        this.updateTime(400);
        this.updatePlayerCount(0);
    }

    loadSettings() {
        const controlMode = this.getSetting('control_mode', 'keyboard');
        const controlModeSelect = document.getElementById('control-mode');
        if (controlModeSelect) controlModeSelect.value = controlMode;
        
        const volume = this.getSetting('volume', '70');
        const volumeSlider = document.getElementById('volume-slider');
        if (volumeSlider) {
            volumeSlider.value = volume;
            this.updateVolume(volume);
        }
        
        const playerRole = this.getSetting('player_role', 'mario');
        const playerRoleSelect = document.getElementById('player-role');
        if (playerRoleSelect) playerRoleSelect.value = playerRole;
    }

    saveSetting(key, value) {
        try {
            localStorage.setItem(`mario_${key}`, value);
        } catch (error) {
            console.warn('设置保存失败:', error);
        }
    }

    getSetting(key, defaultValue = null) {
        try {
            return localStorage.getItem(`mario_${key}`) || defaultValue;
        } catch (error) {
            return defaultValue;
        }
    }

    updateVolume(volume) {
        const volumeValue = parseInt(volume) / 100;
        // 更新音效音量
        const audioElements = document.querySelectorAll('audio');
        audioElements.forEach(audio => {
            audio.volume = volumeValue;
        });
    }

    toggleChatPanel() {
        const chatPanel = document.querySelector('.chat-panel');
        if (chatPanel) {
            chatPanel.classList.toggle('collapsed');
        }
    }

    renderHearts(lives) {
        const livesElement = document.getElementById('lives-value');
        if (livesElement) {
            livesElement.textContent = lives;
        }
    }

    updateScore(score) {
        const scoreElement = document.getElementById('score-value');
        if (scoreElement) {
            scoreElement.textContent = score.toString().padStart(6, '0');
        }
    }

    updateTime(time) {
        const timeElement = document.getElementById('time-value');
        if (timeElement) {
            timeElement.textContent = time;
            if (time <= 30) {
                timeElement.style.color = '#ff6b6b';
            } else {
                timeElement.style.color = '#feca57';
            }
        }
    }

    updatePlayerCount(count, max = 10) {
        const countElement = document.getElementById('player-count');
        if (countElement) {
            countElement.textContent = `${count}/${max}`;
            if (count >= max - 2) {
                countElement.style.background = '#ff6b6b';
            } else if (count >= max - 5) {
                countElement.style.background = '#feca57';
            } else {
                countElement.style.background = '#1dd1a1';
            }
        }
    }

    updateRoomInfo(roomId) {
        const roomNameElement = document.getElementById('room-name');
        if (roomNameElement && roomId) {
            roomNameElement.textContent = roomId;
        }
    }

    updateRoomList(rooms) {
        const roomList = document.getElementById('room-list');
        if (!roomList) return;
        
        roomList.innerHTML = '';
        
        if (!rooms || rooms.length === 0) {
            roomList.innerHTML = '<div class="no-rooms">暂无可用房间</div>';
            return;
        }
        
        rooms.forEach(room => {
            const roomItem = this.createRoomItem(room);
            roomList.appendChild(roomItem);
        });
    }

    createRoomItem(room) {
        const div = document.createElement('div');
        div.className = 'room-item';
        
        const isFull = room.currentPlayers >= room.maxPlayers;
        const canJoin = !room.isPlaying && !isFull;
        
        div.innerHTML = `
            <div class="room-info">
                <h4>${room.roomName || room.roomId}</h4>
                <p>房间ID: ${room.roomId}</p>
                <p class="room-status-text">${room.isPlaying ? '游戏中' : '等待中'}</p>
            </div>
            <div class="room-status">
                <span class="room-players">${room.currentPlayers}/${room.maxPlayers}</span>
                <button class="btn-join ${!canJoin ? 'disabled' : ''}" 
                        ${!canJoin ? 'disabled' : ''}
                        data-room-id="${room.roomId}">
                    ${isFull ? '已满' : room.isPlaying ? '游戏中' : '加入'}
                </button>
            </div>
        `;
        
        const joinBtn = div.querySelector('.btn-join');
        if (canJoin) {
            joinBtn.addEventListener('click', () => {
                if (window.gameApp) {
                    window.gameApp.joinRoom(room.roomId);
                }
            });
        }
        
        return div;
    }

    showCreateRoomModal() {
        const modal = document.getElementById('create-room-modal');
        if (modal) modal.classList.remove('hidden');
    }

    hideCreateRoomModal() {
        const modal = document.getElementById('create-room-modal');
        if (modal) modal.classList.add('hidden');
    }

    async createRoom() {
        const roomNameInput = document.getElementById('room-name-input');
        const roomName = roomNameInput ? roomNameInput.value.trim() : '我的房间';
        
        this.showNotification(`创建房间功能开发中，将为您加入可用房间`, 'info');
        this.hideCreateRoomModal();
        
        // 加入默认房间（room-1）
        if (window.gameApp) {
            // 稍等一会儿让模态框关闭
            setTimeout(() => {
                window.gameApp.joinRoom('room-1');
            }, 500);
        }
    }

    addChatMessage(sender, message, isSystem = false) {
        const chatMessages = document.getElementById('chat-messages');
        if (!chatMessages) return;
        
        const messageElement = document.createElement('div');
        messageElement.className = `chat-message ${isSystem ? 'system-message' : ''}`;
        
        const time = new Date().toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
        
        if (isSystem) {
            messageElement.innerHTML = `
                <span class="message-time">${time}</span>
                <span class="message-content system">${message}</span>
            `;
        } else {
            messageElement.innerHTML = `
                <span class="message-time">${time}</span>
                <span class="message-sender">${sender}:</span>
                <span class="message-content">${message}</span>
            `;
        }
        
        chatMessages.appendChild(messageElement);
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }

    sendChatMessage() {
        const chatInput = document.getElementById('chat-input');
        if (!chatInput) return;
        
        const message = chatInput.value.trim();
        if (!message) return;
        
        if (window.gameWebSocket && window.gameWebSocket.isConnected()) {
            if (window.gameWebSocket.sendChatMessage(message)) {
                chatInput.value = '';
            }
        } else {
            // 如果未连接，显示本地消息
            if (window.gameApp && window.gameApp.player) {
                this.addChatMessage(window.gameApp.player.name, message);
                chatInput.value = '';
            }
        }
    }

    showNotification(message, type = 'info') {
        console.log('通知:', message, type);
        // 可以在这里实现弹窗通知
        if (type === 'error') {
            alert('错误: ' + message);
        } else if (type === 'warning') {
            alert('注意: ' + message);
        }
    }

    updateServerStatus(connected, message = '') {
        const indicator = document.getElementById('server-status-indicator');
        const text = document.getElementById('server-status-text');
        
        if (indicator && text) {
            if (connected) {
                indicator.className = 'status-indicator online';
                text.textContent = message || '服务器连接正常';
            } else {
                indicator.className = 'status-indicator offline';
                text.textContent = message || '服务器连接失败';
            }
        }
    }

    showScreen(screenName) {
        // 隐藏所有屏幕
        document.querySelectorAll('.screen').forEach(el => {
            el.classList.add('hidden');
        });
        
        // 显示目标屏幕
        const targetScreen = document.getElementById(`${screenName}-screen`);
        if (targetScreen) {
            targetScreen.classList.remove('hidden');
            this.currentView = screenName;
        }
    }
}

// 创建全局UI控制器
window.uiController = new UIController();