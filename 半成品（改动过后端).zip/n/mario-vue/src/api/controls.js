/**
 * 游戏控制管理器
 */
class GameControls {
    constructor() {
        this.keys = {};
        this.touchState = {};
        this.isTouchDevice = 'ontouchstart' in window;
        this.touchControlsVisible = false;
        
        this.init();
    }

    init() {
        this.initKeyboardControls();
        
        if (this.isTouchDevice) {
            this.initTouchControls();
            this.showTouchControls(true);
        }
    }

    initKeyboardControls() {
        document.addEventListener('keydown', (e) => {
            this.keys[e.code] = true;
            this.handleKeys();
            
            if (['Space', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(e.code)) {
                e.preventDefault();
            }
        });

        document.addEventListener('keyup', (e) => {
            this.keys[e.code] = false;
            this.handleKeys();
        });

        window.addEventListener('blur', () => {
            this.keys = {};
        });
    }

    initTouchControls() {
        const leftBtn = document.getElementById('btn-touch-left');
        const rightBtn = document.getElementById('btn-touch-right');
        const jumpBtn = document.getElementById('btn-touch-jump');
        
        if (leftBtn) {
            leftBtn.addEventListener('touchstart', () => this.simulateKeyPress('ArrowLeft', true));
            leftBtn.addEventListener('touchend', () => this.simulateKeyPress('ArrowLeft', false));
            leftBtn.addEventListener('touchcancel', () => this.simulateKeyPress('ArrowLeft', false));
        }
        
        if (rightBtn) {
            rightBtn.addEventListener('touchstart', () => this.simulateKeyPress('ArrowRight', true));
            rightBtn.addEventListener('touchend', () => this.simulateKeyPress('ArrowRight', false));
            rightBtn.addEventListener('touchcancel', () => this.simulateKeyPress('ArrowRight', false));
        }
        
        if (jumpBtn) {
            jumpBtn.addEventListener('touchstart', () => {
                this.simulateKeyPress('Space', true);
                setTimeout(() => this.simulateKeyPress('Space', false), 100);
            });
        }
    }

    simulateKeyPress(keyCode, isPressed) {
        this.keys[keyCode] = isPressed;
        this.handleKeys();
    }

    handleKeys() {
        if (!window.gameApp || !window.gameApp.game || !window.gameApp.player) return;
        
        const playerId = window.gameApp.player.id;
        const game = window.gameApp.game;
        
        // 移动控制
        if (this.keys['ArrowLeft'] || this.keys['KeyA']) {
            if (game.movePlayer) {
                game.movePlayer(playerId, 'LEFT');
            }
        } else if (this.keys['ArrowRight'] || this.keys['KeyD']) {
            if (game.movePlayer) {
                game.movePlayer(playerId, 'RIGHT');
            }
        } else {
            if (game.movePlayer) {
                game.movePlayer(playerId, 'STOP');
            }
        }
        
        // 跳跃
        if (this.keys['Space'] || this.keys['ArrowUp'] || this.keys['KeyW']) {
            if (game.jumpPlayer) {
                game.jumpPlayer(playerId);
            }
        }
        
        // 发送玩家状态到服务器
        this.sendPlayerState();
    }

    sendPlayerState() {
        if (!window.gameApp || !window.gameApp.game || !window.gameApp.player || !window.gameWebSocket) return;
        
        const playerId = window.gameApp.player.id;
        const player = window.gameApp.game.players?.[playerId];
        
        if (player && window.gameWebSocket.sendPlayerUpdate) {
            window.gameWebSocket.sendPlayerUpdate({
                x: player.x,
                y: player.y,
                status: player.status || 'stand--right'
            });
        }
    }

    showTouchControls(show) {
        const touchControls = document.getElementById('touch-controls');
        if (touchControls) {
            touchControls.style.display = show ? 'flex' : 'none';
            this.touchControlsVisible = show;
        }
    }

    updateControlMode(mode) {
        switch(mode) {
            case 'keyboard':
                this.showTouchControls(false);
                break;
            case 'touch':
                this.showTouchControls(true);
                break;
            case 'both':
                this.showTouchControls(this.isTouchDevice);
                break;
        }
    }
}

// 创建全局控制管理器
window.gameControls = new GameControls();