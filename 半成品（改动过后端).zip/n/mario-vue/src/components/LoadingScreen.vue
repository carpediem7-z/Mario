<template>
  <div class="screen">
    <div class="loading-container">
      <div class="loading-logo">
        <div class="logo-placeholder">M</div>
        <h1>多人马里奥</h1>
      </div>
      <div class="loading-progress">
        <div class="progress-bar">
          <div class="progress-fill" :style="{ width: progress + '%' }"></div>
        </div>
        <div class="loading-text">{{ text }}</div>
      </div>
    </div>
  </div>
</template>

<script setup>
defineProps({
  progress: {
    type: Number,
    default: 0
  },
  text: {
    type: String,
    default: '正在加载...'
  }
})
</script>