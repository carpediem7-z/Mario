<template>
  <div class="modal">
    <div class="modal-content">
      <h2><i class="fas fa-pause"></i> 游戏暂停</h2>
      <div class="modal-buttons">
        <button class="btn btn-primary" @click="resume">
          <i class="fas fa-play"></i> 继续游戏
        </button>
        <button class="btn" @click="changeRoom">
          <i class="fas fa-door-open"></i> 切换房间
        </button>
        <button class="btn btn-warning" @click="backToMenu">
          <i class="fas fa-home"></i> 返回大厅
        </button>
      </div>
    </div>
  </div>
</template>

<script setup>
import { defineEmits } from 'vue'

const emit = defineEmits(['resume', 'change-room', 'back-menu'])

const resume = () => {
  emit('resume')
}

const changeRoom = () => {
  emit('change-room')
}

const backToMenu = () => {
  emit('back-menu')
}
</script>

<style scoped>
.modal {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.7);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 1000;
}

.modal-content {
  background: white;
  padding: 2rem;
  border-radius: 10px;
  min-width: 300px;
  text-align: center;
}

.modal-buttons {
  display: flex;
  flex-direction: column;
  gap: 10px;
  margin-top: 20px;
}

.btn {
  padding: 10px 20px;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  font-size: 16px;
  transition: background-color 0.3s;
}

.btn-primary {
  background-color: #4CAF50;
  color: white;
}

.btn:hover {
  opacity: 0.9;
}

.btn-warning {
  background-color: #f44336;
  color: white;
}
</style>