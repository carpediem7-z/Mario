<template>
  <div class="screen">
    <div class="menu-header">
      <h1><i class="fas fa-gamepad"></i> 马里奥游戏大厅</h1>
      <div class="player-info">
        <span class="player-name">{{ playerInfo.username }}</span>
        <img :src="getAvatarUrl()" class="player-avatar" alt="头像">
        <button class="btn-icon logout-btn" title="退出登录" @click="logout">
          <i class="fas fa-sign-out-alt"></i>
        </button>
      </div>
    </div>
    
    <div class="menu-content">
      <!-- 房间列表 -->
      <div class="menu-section">
        <h2><i class="fas fa-door-open"></i> 房间列表</h2>
        <div class="room-list">
          <div v-if="rooms.length === 0" class="no-rooms">
            暂无房间，请创建一个！
          </div>
          <div 
            v-for="room in rooms" 
            :key="room.id" 
            class="room-item"
            @click="joinRoom(room.id)"
          >
            <div class="room-name">{{ room.name }}</div>
            <div class="room-info">
              <span class="room-players">{{ room.players }}/{{ room.maxPlayers }}</span>
              <span class="room-status" :class="room.status">{{ room.status === 'playing' ? '游戏中' : '等待中' }}</span>
            </div>
          </div>
        </div>
        <div class="room-actions">
          <button class="btn btn-secondary" @click="refresh">
            <i class="fas fa-sync-alt"></i> 刷新列表
          </button>
          <button class="btn btn-primary" @click="createRoom">
            <i class="fas fa-plus"></i> 创建房间
          </button>
        </div>
      </div>
      
      <!-- 游戏说明和设置部分... -->
    </div>
  </div>
</template>

<script setup>
import { defineProps, defineEmits, computed } from 'vue'

const props = defineProps({
  playerInfo: {
    type: Object,
    required: true
  },
  rooms: {
    type: Array,
    default: () => []
  }
})

const emit = defineEmits([
  'logout',
  'refresh-rooms',
  'create-room',
  'join-room',
  'update-settings'
])

const getAvatarUrl = () => {
  return props.playerInfo.avatar || `/assets/avatars/${props.playerInfo.role}.png`
}

const logout = () => {
  emit('logout')
}

const refresh = () => {
  emit('refresh-rooms')
}

const createRoom = () => {
  emit('create-room')
}

const joinRoom = (roomId) => {
  emit('join-room', roomId)
}
</script>