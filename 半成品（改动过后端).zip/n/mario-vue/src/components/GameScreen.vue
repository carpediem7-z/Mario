<template>
  <div class="screen">
    <!-- HUD -->
    <div class="hud">
      <div class="hud-left">
        <div class="score-display">
          <i class="fas fa-star"></i>
          <span>分数: {{ marioScore }}</span>
        </div>
      </div>
      <div class="hud-center">
        <div class="room-info">
          房间: {{ roomInfo?.name }}
          <span class="player-count">({{ roomInfo?.players?.length || 0 }})</span>
        </div>
      </div>
      <div class="hud-right">
        <div class="health-display">
          <div class="hearts">
            <i v-for="i in 3" :key="i" class="fas fa-heart" :class="{ 'heart-lost': i > gameState.health }"></i>
          </div>
        </div>
      </div>
    </div>
    
    <!-- 游戏画布 -->
    <div class="game-container">
      <canvas ref="gameCanvas"></canvas>
    </div>
    
    <!-- 触摸控制 -->
    <div class="touch-controls">
      <div class="touch-buttons">
        <div class="touch-button" @touchstart="moveLeft" @touchend="stopMove">
          <i class="fas fa-arrow-left"></i>
        </div>
        <div class="touch-button" @touchstart="moveRight" @touchend="stopMove">
          <i class="fas fa-arrow-right"></i>
        </div>
        <div class="touch-button" @touchstart="jump">
          <i class="fas fa-arrow-up"></i>
        </div>
      </div>
    </div>
    
    <!-- 游戏结束屏幕 -->
    <div v-if="gameOver" class="game-over-screen">
      <div class="game-over-content">
        <h1>游戏结束</h1>
        <p>你的得分: {{ marioScore }}</p>
        <button @click="restartGame">重新开始</button>
      </div>
    </div>
    
    <!-- 游戏胜利屏幕 -->
    <div v-if="gameWon" class="game-won-screen">
      <div class="game-won-content">
        <h1>游戏胜利</h1>
        <p>你的得分: {{ marioScore }}</p>
        <button @click="restartGame">重新开始</button>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, onUnmounted, defineProps, defineEmits } from 'vue'
import { connectWebSocket, disconnectWebSocket, sendMessage, addMessageHandler } from '../utils/websocket'

const props = defineProps({
  roomInfo: Object,
  playerInfo: Object,
  gameState: {
    type: Object,
    default: () => ({
      score: 0,
      health: 3,
      paused: false
    })
  }
})

// 图片资源
const backgroundImage = ref(new Image())
const backgroundImage2 = ref(new Image())
const marioStandRight = ref(new Image())
const marioStandLeft = ref(new Image())
const marioRunRight1 = ref(new Image())
const marioRunRight2 = ref(new Image())
const marioRunLeft1 = ref(new Image())
const marioRunLeft2 = ref(new Image())
const marioJumpRight = ref(new Image())
const marioJumpLeft = ref(new Image())

// 障碍物图片
const brickImage = ref(new Image())
const brick2Image = ref(new Image())
const pipe1Image = ref(new Image())
const pipe2Image = ref(new Image())
const pipe3Image = ref(new Image())
const pipe4Image = ref(new Image())
const soilBaseImage = ref(new Image())
const soilUpImage = ref(new Image())

// 小怪图片
const fungus1Image = ref(new Image())
const fungus2Image = ref(new Image())
const fungus3Image = ref(new Image())
const flower1Image = ref(new Image())
const flower2Image = ref(new Image())

// 场景元素
const towerImage = ref(new Image())
const ganImage = ref(new Image())
const flagImage = ref(new Image())

// 小怪状态
const enemies = ref([
  { id: 1, x: 580, y: 385, width: 40, height: 40, direction: 1, speed: 0.5, alive: true, type: 1 }, // 蘑菇敌人
  { id: 2, x: 635, y: 420, width: 40, height: 40, direction: 1, speed: 0.5, alive: true, type: 2 }  // 食人花敌人
])

// 障碍物状态
const obstacles = ref([])

// 初始化第一关地图
const initLevel1Map = () => {
  obstacles.value = []
  
  // 地板
  for (let i = 0; i < 27; i++) {
    obstacles.value.push({ id: obstacles.value.length + 1, x: i * 30, y: 420, width: 30, height: 30, type: 1 }) // 地板砖
  }
  
  // 底部土壤
  for (let j = 0; j <= 120; j += 30) {
    for (let i = 0; i < 27; i++) {
      obstacles.value.push({ id: obstacles.value.length + 1, x: i * 30, y: 570 - j, width: 30, height: 30, type: 2 }) // 土壤
    }
  }
  
  // 砖块A
  for (let i = 120; i <= 150; i += 30) {
    obstacles.value.push({ id: obstacles.value.length + 1, x: i, y: 300, width: 30, height: 30, type: 7 }) // 空砖块
  }
  
  // 砖块B-F
  for (let i = 300; i <= 570; i += 30) {
    if (i === 360 || i === 390 || i === 480 || i === 510 || i === 540) {
      obstacles.value.push({ id: obstacles.value.length + 1, x: i, y: 300, width: 30, height: 30, type: 7 }) // 空砖块
    } else {
      obstacles.value.push({ id: obstacles.value.length + 1, x: i, y: 300, width: 30, height: 30, type: 0 }) // 可破坏砖块
    }
  }
  
  // 砖块G
  for (let i = 420; i <= 450; i += 30) {
    obstacles.value.push({ id: obstacles.value.length + 1, x: i, y: 240, width: 30, height: 30, type: 7 }) // 空砖块
  }
  
  // 水管
  for (let i = 360; i <= 600; i += 25) {
    if (i === 360) {
      obstacles.value.push({ id: obstacles.value.length + 1, x: 620, y: i, width: 25, height: 25, type: 3 }) // 水管头部左
      obstacles.value.push({ id: obstacles.value.length + 1, x: 645, y: i, width: 25, height: 25, type: 4 }) // 水管头部右
    } else {
      obstacles.value.push({ id: obstacles.value.length + 1, x: 620, y: i, width: 25, height: 25, type: 5 }) // 水管身体左
      obstacles.value.push({ id: obstacles.value.length + 1, x: 645, y: i, width: 25, height: 25, type: 6 }) // 水管身体右
    }
  }
}

// 初始化地图
onMounted(() => {
  initLevel1Map()
})

const emit = defineEmits(['pause', 'back-to-menu', 'change-room', 'update:playerInfo', 'update:gameState'])

const gameCanvas = ref(null)
let canvasContext = null
let animationFrameId = null
let players = ref([])

// 马里奥状态管理
const marioStatus = ref('stand--right')
const marioIndex = ref(0)
const marioX = ref(10)
const marioY = ref(355)
const marioXSpeed = ref(0)
const marioYSpeed = ref(0)
const marioUpTime = ref(0)
const marioMoved = ref(false)

// 游戏状态管理和得分系统
const marioScore = ref(0)
const marioIsDeath = ref(false)
const marioIsOK = ref(false)
const gameOver = ref(false)
const gameWon = ref(false)

// 当前场景
const currentScene = ref(0)
const scenes = ref([
  { id: 1, background: backgroundImage, obstacles: [], enemies: [] },
  { id: 2, background: backgroundImage2, obstacles: [], enemies: [] },
  { id: 3, background: backgroundImage2, obstacles: [], enemies: [] }
])

// 键盘控制
const keys = {
  ArrowLeft: false,
  ArrowRight: false,
  ArrowUp: false
}

onMounted(() => {
  initCanvas()
  initControls()
  initWebSocket()
  loadImages()
  initLevel1Map()
  gameLoop()
  
  // 监听键盘事件
  window.addEventListener('keydown', handleKeyDown)
  window.addEventListener('keyup', handleKeyUp)
  
  // 监听游戏暂停事件（如按ESC键）
  window.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      emit('pause')
    }
  })
  
  // 初始化马里奥位置
  if (props.playerInfo) {
    marioX.value = props.playerInfo.x || 10
    marioY.value = props.playerInfo.y || 380
  }
})

const loadImages = () => {
  // 加载背景图片
  backgroundImage.value.src = '/images/bg.png'
  backgroundImage2.value.src = '/images/bg2.png'
  
  // 加载马里奥角色图片
  marioStandRight.value.src = '/images/s_mario_stand_R.png'
  marioStandLeft.value.src = '/images/s_mario_stand_L.png'
  marioRunRight1.value.src = '/images/s_mario_run1_R.png'
  marioRunRight2.value.src = '/images/s_mario_run2_R.png'
  marioRunLeft1.value.src = '/images/s_mario_run1_L.png'
  marioRunLeft2.value.src = '/images/s_mario_run2_L.png'
  marioJumpRight.value.src = '/images/s_mario_jump1_R.png'
  marioJumpLeft.value.src = '/images/s_mario_jump1_L.png'
  
  // 加载障碍物图片
  brickImage.value.src = '/images/brick.png'
  brick2Image.value.src = '/images/brick2.png'
  pipe1Image.value.src = '/images/pipe1.png'
  pipe2Image.value.src = '/images/pipe2.png'
  pipe3Image.value.src = '/images/pipe3.png'
  pipe4Image.value.src = '/images/pipe4.png'
  soilBaseImage.value.src = '/images/soil_base.png'
  soilUpImage.value.src = '/images/soil_up.png'
  
  // 加载小怪图片
  fungus1Image.value.src = '/images/fungus1.png'
  fungus2Image.value.src = '/images/fungus2.png'
  fungus3Image.value.src = '/images/fungus3.png'
  flower1Image.value.src = '/images/flower1.1.png'
  flower2Image.value.src = '/images/flower1.2.png'
  
  // 加载场景元素
  towerImage.value.src = '/images/tower.png'
  ganImage.value.src = '/images/gan.png'
  flagImage.value.src = '/images/flag.png'
  
  // 图片加载完成后重新绘制
  backgroundImage.value.onload = draw
  backgroundImage2.value.onload = draw
  marioStandRight.value.onload = draw
  marioStandLeft.value.onload = draw
  marioRunRight1.value.onload = draw
  marioRunRight2.value.onload = draw
  marioRunLeft1.value.onload = draw
  marioRunLeft2.value.onload = draw
  marioJumpRight.value.onload = draw
  marioJumpLeft.value.onload = draw
  brickImage.value.onload = draw
  brick2Image.value.onload = draw
  pipe1Image.value.onload = draw
  pipe2Image.value.onload = draw
  pipe3Image.value.onload = draw
  pipe4Image.value.onload = draw
  soilBaseImage.value.onload = draw
  soilUpImage.value.onload = draw
  fungus1Image.value.onload = draw
  fungus2Image.value.onload = draw
  fungus3Image.value.onload = draw
  flower1Image.value.onload = draw
  flower2Image.value.onload = draw
  towerImage.value.onload = draw
  ganImage.value.onload = draw
  flagImage.value.onload = draw
}

const initWebSocket = () => {
  connectWebSocket({
    onOpen: () => {
      console.log('WebSocket connected to game server')
    },
    onClose: () => {
      console.log('WebSocket disconnected from game server')
    },
    onMessage: (message) => {
      handleWebSocketMessage(message)
    }
  })
}

onUnmounted(() => {
  window.removeEventListener('keydown', handleKeyDown)
  window.removeEventListener('keyup', handleKeyUp)
  disconnectWebSocket()
  if (animationFrameId) {
    cancelAnimationFrame(animationFrameId)
  }
})

const handleWebSocketMessage = (message) => {
  switch (message.type) {
    case 'welcome':
      console.log('Welcome message:', message)
      // 保存玩家信息到父组件
      if (message.data && message.data.player) {
        emit('update:playerInfo', message.data.player)
      } else if (message.player) {
        // 兼容没有data属性的welcome消息
        emit('update:playerInfo', message.player)
      }
      break
    case 'gameState':
      console.log('Game state update:', message)
      // 更新游戏状态到父组件
      if (message.data && message.data.gameState) {
        emit('update:gameState', message.data.gameState)
      }
      // 更新玩家列表
          // 处理后端可能返回的对象形式的玩家数据
          if (Array.isArray(message.data?.players)) {
            players.value = message.data.players
          } else if (typeof message.data?.players === 'object' && message.data.players !== null) {
            // 如果是对象，转换为数组
            players.value = Object.values(message.data.players)
          } else {
            players.value = []
          }
          console.log('Players updated:', players.value)
          console.log('Player positions:', players.value.map(p => ({id: p.id, x: p.x, y: p.y, direction: p.direction, status: p.status})))
      break
    case 'playerMove':
      console.log('Player move:', message)
      // 更新玩家位置
      if (message.data && message.data.player) {
        const index = players.value.findIndex(p => p.id === message.data.player.id)
        if (index !== -1) {
          players.value[index] = message.data.player
        }
      }
      break
    case 'chatMessage':
      console.log('Chat message:', message)
      // 可以添加聊天消息处理逻辑，比如弹出提示或显示聊天框
      break
    default:
      console.log('Unknown message type:', message)
  }
}

const initCanvas = () => {
  if (gameCanvas.value) {
    canvasContext = gameCanvas.value.getContext('2d')
    gameCanvas.value.width = 800
    gameCanvas.value.height = 600
    
    // 绘制初始游戏画面
    draw()
  }
}

const initControls = () => {
  // 初始化游戏控制
}

const handleKeyDown = (e) => {
  if (keys.hasOwnProperty(e.key)) {
    keys[e.key] = true
    e.preventDefault()
  }
}

const handleKeyUp = (e) => {
  if (keys.hasOwnProperty(e.key)) {
    keys[e.key] = false
    e.preventDefault()
  }
}

const moveLeft = () => {
  keys.ArrowLeft = true
}

const moveRight = () => {
  keys.ArrowRight = true
}

const stopMove = () => {
  keys.ArrowLeft = false
  keys.ArrowRight = false
}

const jump = () => {
  keys.ArrowUp = true
  setTimeout(() => {
    keys.ArrowUp = false
  }, 200)
}

const gameLoop = () => {
  if (!props.gameState.paused && !gameOver.value && !gameWon.value) {
    update()
    draw()
  } else {
    draw()
  }
  animationFrameId = requestAnimationFrame(gameLoop)
}

const update = () => {
    // 游戏逻辑更新
    // 键盘控制已经在handleKeyDown和handleKeyUp中处理
    // 触摸控制已经在moveLeft、moveRight、stopMove和jump中处理
    
    // 键盘控制
    if (keys.ArrowLeft) {
      marioXSpeed.value = -5
      marioStatus.value = marioStatus.value.includes('jump') ? 'jump--left' : 'move--left'
    } else if (keys.ArrowRight) {
      marioXSpeed.value = 5
      marioStatus.value = marioStatus.value.includes('jump') ? 'jump--right' : 'move--right'
    } else {
      marioXSpeed.value = 0
      marioStatus.value = marioStatus.value.includes('jump') ? marioStatus.value : (marioStatus.value.includes('left') ? 'stop--left' : 'stop--right')
    }
    
    // 跳跃逻辑
    if (keys.ArrowUp && marioUpTime.value === 0 && marioY.value >= 375 && marioY.value <= 380) {
      marioYSpeed.value = -14
      marioUpTime.value = 12
      marioStatus.value = marioStatus.value.includes('left') ? 'jump--left' : 'jump--right'
    }
    
    // 更新马里奥位置
    marioX.value += marioXSpeed.value
    
    // 跳跃计时
    if (marioUpTime.value > 0) {
      marioY.value += marioYSpeed.value
      marioUpTime.value--
    } else {
      // 下落
      marioY.value += 5
    }
    
    // 边界检测
    if (marioX.value < 0) marioX.value = 0
    if (marioX.value > 775) {
      // 切换到第二关
      currentScene.value = 1
      marioX.value = 10
      marioY.value = 355
    }
    if (marioY.value > 380) {
      marioY.value = 380
      marioUpTime.value = 0
      marioYSpeed.value = 0
      marioStatus.value = marioStatus.value.includes('left') ? 'stop--left' : 'stop--right'
    }
    
    // 同步马里奥位置到玩家列表
    if (Array.isArray(players.value)) {
      // 单人模式下确保自己的角色存在
      if (props.roomInfo?.maxPlayers === 1) {
        // 过滤掉其他玩家
        players.value = players.value.filter(player => player.id === props.playerInfo?.id)
        
        // 如果玩家列表为空，添加自己的角色
        if (players.value.length === 0 && props.playerInfo) {
          players.value.push({
            id: props.playerInfo.id,
            name: props.playerInfo.username,
            role: 'mario',
            x: marioX.value,
            y: marioY.value,
            status: marioStatus.value
          })
        }
      }
      
      // 更新自己的位置
      players.value.forEach((player, index) => {
        if (player.id === props.playerInfo?.id) {
          players.value[index] = {
            ...player,
            x: marioX.value,
            y: marioY.value,
            status: marioStatus.value
          }
        }
      })
    }
    
    // 更新小怪位置
    enemies.value.forEach(enemy => {
      if (enemy.alive) {
        if (enemy.type === 1) { // 蘑菇敌人
          enemy.x += enemy.direction * enemy.speed
          
          // 小怪碰到边界后改变方向
          if (enemy.x < 250 || enemy.x > 350) {
            enemy.direction *= -1
          }
          
          // 小怪动画
          enemy.frame = Math.floor(Date.now() / 200) % 2
        } else if (enemy.type === 2) { // 食人花敌人
          // 食人花上下移动
          enemy.y += enemy.direction * enemy.speed
          
          // 碰到边界后改变方向
          if (enemy.y < 328 || enemy.y > 428) {
            enemy.direction *= -1
          }
          
          // 食人花动画
          enemy.frame = Math.floor(Date.now() / 200) % 2
        }
      }
    })
    
    // 碰撞检测
    if (Array.isArray(players.value) && players.value.length > 0) {
      players.value.forEach(player => {
        const playerX = player.x || 100
        const playerY = player.y || 450
        
        enemies.value.forEach(enemy => {
          if (enemy.alive) {
            // 检测马里奥是否跳到小怪头上
            if (playerY + 40 >= enemy.y && playerY + 40 <= enemy.y + 10 && 
                playerX + 15 >= enemy.x && playerX + 15 <= enemy.x + enemy.width) {
              enemy.alive = false
              marioScore.value += 100
            } 
            // 检测马里奥是否碰到小怪身体
            else if (playerX < enemy.x + enemy.width && playerX + 30 > enemy.x && 
                     playerY < enemy.y + enemy.height && playerY + 40 > enemy.y && !gameOver.value) {
              // 马里奥死亡，回到初始位置
              sendMessage({ type: 'playerRespawn' })
              marioIsDeath.value = true
              gameOver.value = true
            }
          }
        })
        
        // 障碍物碰撞检测
        obstacles.value.forEach((obstacle, index) => {
          // 检测马里奥是否在障碍物上方
          if (playerY + 40 <= obstacle.y && playerY + 40 >= obstacle.y - 10 && 
              playerX + 30 > obstacle.x && playerX < obstacle.x + obstacle.width) {
            // 马里奥站在障碍物上
            marioY.value = obstacle.y - 40
            marioUpTime.value = 0
            marioYSpeed.value = 0
          }
          // 检测马里奥是否碰到障碍物顶部
          else if (playerY <= obstacle.y + obstacle.height && playerY >= obstacle.y + obstacle.height - 10 && 
                   playerX + 30 > obstacle.x && playerX < obstacle.x + obstacle.width) {
            // 马里奥碰到障碍物顶部
            marioY.value = obstacle.y + obstacle.height
            marioUpTime.value = 0
          }
          // 检测马里奥是否碰到障碍物左侧
          else if (playerX + 30 >= obstacle.x && playerX + 30 <= obstacle.x + 10 && 
                   playerY + 40 > obstacle.y && playerY < obstacle.y + obstacle.height) {
            // 马里奥碰到障碍物左侧
            marioX.value = obstacle.x - 30
          }
          // 检测马里奥是否碰到障碍物右侧
          else if (playerX <= obstacle.x + obstacle.width && playerX >= obstacle.x + obstacle.width - 10 && 
                   playerY + 40 > obstacle.y && playerY < obstacle.y + obstacle.height) {
            // 马里奥碰到障碍物右侧
            marioX.value = obstacle.x + obstacle.width
          }
          // 判断是否跳起来顶到方块
          if ((obstacle.y >= playerY - 20 && obstacle.y <= playerY - 10) && (obstacle.x > playerX - 20 && obstacle.x < playerX + 15)) {
            if (obstacle.type === 0) {
              // 破坏砖块
              obstacles.value.splice(index, 1)
              marioScore.value += 100
            }
            marioUpTime.value = 0
          }
        })
        
        // 检测是否到达终点
        if (playerX > 700 && !gameOver.value) {
          gameWon.value = true
          marioIsOK.value = true
        }
      })
    }
  }

const draw = () => {
  if (!canvasContext) return
  
  // 清除画布
  canvasContext.clearRect(0, 0, gameCanvas.value.width, gameCanvas.value.height)
  
  // 绘制游戏背景
  if (backgroundImage.value.complete && backgroundImage.value.naturalHeight > 0) {
    // 平铺背景图片
    const pattern = canvasContext.createPattern(backgroundImage.value, 'repeat-x')
    canvasContext.fillStyle = pattern
    canvasContext.fillRect(0, 0, gameCanvas.value.width, gameCanvas.value.height)
  } else {
    // 图片加载失败时使用默认背景色
    canvasContext.fillStyle = '#87CEEB'
    canvasContext.fillRect(0, 0, gameCanvas.value.width, gameCanvas.value.height)
  }
  
  // 绘制地面
  canvasContext.fillStyle = '#8B4513'
  canvasContext.fillRect(0, 500, gameCanvas.value.width, 100)
  
  // 绘制障碍物
  if (brickImage.value.complete && brickImage.value.naturalHeight > 0) {
    obstacles.value.forEach(obstacle => {
      switch (obstacle.type) {
        case 0: // 可破坏砖块
          canvasContext.drawImage(brickImage.value, obstacle.x, obstacle.y, obstacle.width, obstacle.height)
          break
        case 1: // 地板砖
          canvasContext.drawImage(brick2Image.value, obstacle.x, obstacle.y, obstacle.width, obstacle.height)
          break
        case 2: // 土壤
          if (obstacle.y === 480) {
            canvasContext.drawImage(soilBaseImage.value, obstacle.x, obstacle.y, obstacle.width, obstacle.height)
          } else {
            canvasContext.drawImage(soilUpImage.value, obstacle.x, obstacle.y, obstacle.width, obstacle.height)
          }
          break
        case 3: // 水管头部左
          canvasContext.drawImage(pipe1Image.value, obstacle.x, obstacle.y, obstacle.width, obstacle.height)
          break
        case 4: // 水管头部右
          canvasContext.drawImage(pipe2Image.value, obstacle.x, obstacle.y, obstacle.width, obstacle.height)
          break
        case 5: // 水管身体左
          canvasContext.drawImage(pipe3Image.value, obstacle.x, obstacle.y, obstacle.width, obstacle.height)
          break
        case 6: // 水管身体右
          canvasContext.drawImage(pipe4Image.value, obstacle.x, obstacle.y, obstacle.width, obstacle.height)
          break
        case 7: // 空砖块
          canvasContext.drawImage(brick2Image.value, obstacle.x, obstacle.y, obstacle.width, obstacle.height)
          break
      }
    })
  }
  
  // 绘制小怪
  if (fungus1Image.value.complete && fungus1Image.value.naturalHeight > 0) {
    enemies.value.forEach(enemy => {
      if (enemy.alive) {
        // 小怪动画
        let enemyImage
        if (enemy.type === 1) { // 蘑菇敌人
          enemyImage = enemy.frame === 0 ? fungus1Image.value : fungus2Image.value
        } else if (enemy.type === 2) { // 食人花敌人
          enemyImage = enemy.frame === 0 ? flower1Image.value : flower2Image.value
        }
        canvasContext.drawImage(enemyImage, enemy.x, enemy.y, enemy.width, enemy.height)
      }
    })
  }
  
  // 绘制所有玩家
  if (Array.isArray(players.value) && players.value.length > 0) {
    players.value.forEach((player, index) => {
      const x = player.x || 100 + index * 100
      const y = player.y || 450
      
      // 绘制马里奥角色图片
        if (player.role === 'mario') {
          let marioImage = marioStandRight.value
          
          // 根据玩家状态选择合适的图片
          if (player.status === 'jump--right' || player.status === 'jump--left') {
            marioImage = player.status === 'jump--left' ? marioJumpLeft.value : marioJumpRight.value
          } else if (player.status === 'move--right' || player.status === 'move--left') {
            // 切换跑步动画帧
            const frameIndex = Math.floor(Date.now() / 150) % 2
            if (player.status === 'move--left') {
              marioImage = frameIndex === 0 ? marioRunLeft1.value : marioRunLeft2.value
            } else {
              marioImage = frameIndex === 0 ? marioRunRight1.value : marioRunRight2.value
            }
          } else {
            marioImage = player.status === 'stop--left' || player.status === 'move--left' ? marioStandLeft.value : marioStandRight.value
          }
          
          // 确保图片已加载完成
          if (marioImage.complete && marioImage.naturalHeight > 0) {
            canvasContext.drawImage(marioImage, x, y, 30, 40) // 调整大小为30x40，与原版一致
          } else {
            // 图片加载失败时使用默认矩形
            canvasContext.fillStyle = '#E52521'
            canvasContext.fillRect(x, y, 30, 40)
          }
        } else {
        // 其他角色使用默认矩形
        canvasContext.fillStyle = '#4CAF50'
        canvasContext.fillRect(x, y, 40, 50)
      }
      
      // 绘制玩家名称
      canvasContext.fillStyle = '#000'
      canvasContext.font = '12px Arial'
      canvasContext.fillText(player.name, x, y - 10)
    })
  }
}

// 重新开始游戏
const restartGame = () => {
  gameOver.value = false
  gameWon.value = false
  marioIsDeath.value = false
  marioIsOK.value = false
  marioScore.value = 0
  
  // 重置马里奥位置
  marioX.value = 10
  marioY.value = 380 // 调整Y坐标，与原版一致
  marioXSpeed.value = 0
  marioYSpeed.value = 0
  marioUpTime.value = 0
  
  // 重置小怪
  enemies.value = [
    { id: 1, x: 580, y: 385, width: 40, height: 40, direction: 1, speed: 0.5, alive: true, type: 1 }, // 蘑菇敌人
    { id: 2, x: 635, y: 420, width: 40, height: 40, direction: 1, speed: 0.5, alive: true, type: 2 }  // 食人花敌人
  ]
  
  // 重置障碍物
  initLevel1Map()
}

// 暴露方法给父组件
defineExpose({
  pauseGame: () => emit('pause'),
  restartGame
})
</script>

<style scoped>
.screen {
  position: relative;
  width: 100%;
  height: 100vh;
  overflow: hidden;
  background: linear-gradient(to bottom, #87CEEB 0%, #98FB98 100%);
}

.hud {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 10px 20px;
  background: rgba(0, 0, 0, 0.5);
  color: white;
  font-family: 'Arial', sans-serif;
  z-index: 100;
}

.hud-left, .hud-right {
  display: flex;
  flex-direction: column;
  gap: 5px;
}

.hud-center {
  text-align: center;
}

.score-display, .health-display {
  display: flex;
  align-items: center;
  gap: 5px;
}

.hearts {
  display: flex;
  gap: 5px;
}

.heart-lost {
  opacity: 0.3;
}

.game-container {
  position: relative;
  width: 100%;
  height: 100%;
  display: flex;
  justify-content: center;
  align-items: center;
}

canvas {
  border: 2px solid #333;
  border-radius: 5px;
  background: #87CEEB;
}

.touch-controls {
  position: absolute;
  bottom: 20px;
  left: 0;
  right: 0;
  display: flex;
  justify-content: center;
  z-index: 100;
}

.touch-buttons {
  display: flex;
  gap: 20px;
}

.touch-button {
  width: 60px;
  height: 60px;
  background: rgba(0, 0, 0, 0.5);
  border-radius: 50%;
  display: flex;
  justify-content: center;
  align-items: center;
  color: white;
  font-size: 24px;
  cursor: pointer;
  user-select: none;
}

.touch-button:active {
  background: rgba(0, 0, 0, 0.7);
  transform: scale(0.95);
}

.game-over-screen, .game-won-screen {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.8);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 200;
}

.game-over-content, .game-won-content {
  background: white;
  padding: 40px;
  border-radius: 10px;
  text-align: center;
  box-shadow: 0 0 20px rgba(0, 0, 0, 0.5);
}

h1 {
  font-size: 48px;
  margin-bottom: 20px;
  color: #E52521;
}

.game-won-content h1 {
  color: #4CAF50;
}

p {
  font-size: 24px;
  margin-bottom: 20px;
  color: #333;
}

button {
  padding: 15px 30px;
  font-size: 20px;
  background: #E52521;
  color: white;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  transition: background 0.3s;
}

button:hover {
  background: #C02020;
}

.game-won-content button {
  background: #4CAF50;
}

.game-won-content button:hover {
  background: #45A049;
}
</style>