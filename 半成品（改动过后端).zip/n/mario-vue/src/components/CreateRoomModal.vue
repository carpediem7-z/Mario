<template>
  <div class="modal">
    <div class="modal-content">
      <h2><i class="fas fa-plus"></i> 创建房间</h2>
      <div class="form-group">
        <input 
          type="text" 
          v-model="roomName" 
          placeholder="房间名称" 
          maxlength="20"
          @keyup.enter="confirm"
        >
      </div>
      <div class="form-group">
        <select v-model="maxPlayers">
          <option value="1">1人（单人模式）</option>
          <option value="2">2人</option>
          <option value="4">4人</option>
          <option value="6">6人</option>
          <option value="10">10人</option>
        </select>
      </div>
      <div class="modal-buttons">
        <button class="btn btn-primary" @click="confirm">
          <i class="fas fa-check"></i> 创建
        </button>
        <button class="btn btn-secondary" @click="cancel">
          <i class="fas fa-times"></i> 取消
        </button>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, defineEmits } from 'vue'

const emit = defineEmits(['create', 'cancel'])

const roomName = ref('我的房间')
const maxPlayers = ref(4)

const confirm = () => {
  emit('create', {
    name: roomName.value,
    maxPlayers: parseInt(maxPlayers.value)
  })
}

const cancel = () => {
  emit('cancel')
}
</script>

<style scoped>
.modal {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.7);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 1000;
}

.modal-content {
  background: white;
  padding: 2rem;
  border-radius: 10px;
  min-width: 300px;
}
</style>