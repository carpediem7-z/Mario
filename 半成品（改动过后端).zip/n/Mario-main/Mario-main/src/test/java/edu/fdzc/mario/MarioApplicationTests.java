package edu.fdzc.mario;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MarioApplicationTests {

    @Test
    void contextLoads() {
    }

}
