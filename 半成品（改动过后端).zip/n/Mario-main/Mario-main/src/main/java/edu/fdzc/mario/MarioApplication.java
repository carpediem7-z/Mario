package edu.fdzc.mario;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MarioApplication {

    public static void main(String[] args) {
        SpringApplication.run(MarioApplication.class, args);
    }

}
