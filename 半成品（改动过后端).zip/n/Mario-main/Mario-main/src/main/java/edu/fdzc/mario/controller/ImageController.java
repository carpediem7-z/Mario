package edu.fdzc.mario.controller;

import org.springframework.core.io.ClassPathResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.nio.file.Files;

@RestController
@RequestMapping("/api/images")
public class ImageController {

    @GetMapping("/{imageName:.+}")
    public ResponseEntity<byte[]> getImage(@PathVariable String imageName) throws IOException {
        try {
            // 构建图片路径（与StaticValue.java中的路径一致）
            String imagePath = "static/images/" + imageName;
            ClassPathResource resource = new ClassPathResource(imagePath);

            if (!resource.exists()) {
                return ResponseEntity.notFound().build();
            }

            // 读取图片文件
            byte[] imageData = Files.readAllBytes(resource.getFile().toPath());

            // 根据文件扩展名设置Content-Type
            String contentType = getContentType(imageName);

            // 设置缓存头
            HttpHeaders headers = new HttpHeaders();
            headers.setCacheControl("public, max-age=86400");

            return ResponseEntity.ok()
                    .headers(headers)
                    .contentType(MediaType.parseMediaType(contentType))
                    .body(imageData);

        } catch (Exception e) {
            return ResponseEntity.status(500).build();
        }
    }

    private String getContentType(String fileName) {
        if (fileName.endsWith(".png")) return "image/png";
        if (fileName.endsWith(".jpg") || fileName.endsWith(".jpeg")) return "image/jpeg";
        if (fileName.endsWith(".gif")) return "image/gif";
        return "application/octet-stream";
    }
}