const API_BASE = '/api'

export const getPlayerInfo = async (playerId) => {
  const response = await fetch(`${API_BASE}/player/${playerId}`)
  return response.json()
}

export const changeRole = async (playerId, role) => {
  const response = await fetch(`${API_BASE}/player/${playerId}/role`, {
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({ role })
  })
  return response.json()
}