<template>
  <div class="screen">
    <div class="auth-container">
      <div class="auth-logo">
        <div class="logo-placeholder">M</div>
        <h2>欢迎来到超级马里奥</h2>
      </div>
      
      <div class="auth-form">
        <div class="form-group">
          <input 
            type="text" 
            v-model="username" 
            placeholder="请输入玩家名" 
            maxlength="12" 
            @keyup.enter="login"
          >
          <i class="fas fa-user"></i>
        </div>
        <div class="auth-buttons">
          <button class="btn btn-primary" @click="login">
            <i class="fas fa-play"></i> 开始游戏
          </button>
          <button class="btn btn-secondary" @click="guestLogin">
            <i class="fas fa-user-clock"></i> 快速开始
          </button>
        </div>
        <div class="server-status">
          <div 
            :class="['status-indicator', serverStatus.connected ? 'online' : 'offline']"
          ></div>
          <span>{{ serverStatus.text }}</span>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, defineProps, defineEmits } from 'vue'

const props = defineProps({
  serverStatus: {
    type: Object,
    default: () => ({
      connected: false,
      text: '正在检测服务器...'
    })
  }
})

const emit = defineEmits(['login', 'guest-login'])

const username = ref('玩家')

const login = () => {
  if (username.value.trim()) {
    emit('login', username.value.trim())
  }
}

const guestLogin = () => {
  emit('guest-login')
}
</script>