<template>
  <div id="app" @click="handleClick">
    <!-- 背景云朵动画 -->
    <div class="background-clouds">
      <div class="cloud" :style="cloud1Style">☁️</div>
      <div class="cloud" :style="cloud2Style">☁️</div>
      <div class="cloud" :style="cloud3Style">☁️</div>
    </div>

    <!-- 点击特效容器 -->
    <div class="click-effects">
      <div
        v-for="effect in clickEffects"
        :key="effect.id"
        class="click-effect"
        :style="effect.style"
      >
        {{ effect.emoji }}
      </div>
    </div>

    <!-- 加载屏幕 -->
    <LoadingScreen
      v-if="currentScreen === 'loading'"
      :progress="loadingProgress"
      :text="loadingText"
    />

    <!-- 登录/注册界面 -->
    <AuthScreen
      v-else-if="currentScreen === 'auth'"
      :server-status="serverStatus"
      @login="handleLogin"
      @guest-login="handleGuestLogin"
    />

    <!-- 游戏屏幕 -->
    <GameScreen
      v-else-if="currentScreen === 'game'"
      :player-info="playerInfo"
      :game-state="gameState"
      @pause="showPauseMenu"
      @back-to-menu="backToMenu"
    />

    <!-- 暂停菜单模态框 -->
    <PauseModal
      v-if="showPauseModal"
      @resume="resumeGame"
      @back-menu="backToMenu"
    />

    <!-- 背景音乐播放器（隐藏） -->
    <audio
      id="bgMusic"
      ref="bgMusicRef"
      :src="musicPath"
      loop
      preload="auto"
    ></audio>

    <!-- 音乐控制按钮（可选） -->
    <button
      v-if="currentScreen !== 'loading'"
      class="music-control"
      @click="toggleMusic"
      :class="{ muted: isMusicMuted }"
      title="音乐开关"
    >
      <i :class="isMusicMuted ? 'fas fa-volume-mute' : 'fas fa-volume-up'"></i>
    </button>

    <!-- 简单的游戏统计显示（只在开发环境显示） -->
    <div v-if="isDev && currentScreen !== 'loading'" class="game-stats">
      <div>🎮 当前页面: {{ currentScreen }}</div>
      <div>👤 用户: {{ playerInfo.username || '未登录' }}</div>
      <div>🏆 分数: {{ gameState.score }}</div>
    </div>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted, onUnmounted, computed, nextTick } from 'vue'
import LoadingScreen from './components/LoadingScreen.vue'
import AuthScreen from './components/AuthScreen.vue'
import GameScreen from './components/GameScreen.vue'
import PauseModal from './components/PauseModal.vue'
import { connectWebSocket, disconnectWebSocket } from './utils/websocket'

// 状态管理
const currentScreen = ref('loading')
const loadingProgress = ref(0)
const loadingText = ref('正在连接服务器...')
const serverStatus = reactive({
  connected: false,
  text: '正在检测服务器...'
})
const playerInfo = reactive({
  username: '',
  role: 'mario',
  avatar: '',
  isGuest: false
})
const gameState = reactive({
  score: 0,
  health: 3,
  paused: false
})
const showPauseModal = ref(false)

// 音乐相关状态
const bgMusicRef = ref(null)
const isMusicMuted = ref(false)
const musicPath = computed(() => {
  return '/sounds/music.wav'
})

// ========== 新增的特效部分 ==========

// 1. 点击特效
const clickEffects = ref([])
let clickEffectId = 0

const handleClick = (event) => {
  // 如果点击的是音乐按钮，不触发特效
  if (event.target.closest('.music-control')) return

  const emojis = ['⭐', '✨', '🪙', '🍄', '🌸', '🔥']
  const emoji = emojis[Math.floor(Math.random() * emojis.length)]

  const newEffect = {
    id: clickEffectId++,
    emoji: emoji,
    style: {
      left: `${event.clientX}px`,
      top: `${event.clientY}px`,
      fontSize: `${20 + Math.random() * 20}px`,
      color: getRandomColor()
    }
  }

  clickEffects.value.push(newEffect)

  // 3秒后移除特效
  setTimeout(() => {
    clickEffects.value = clickEffects.value.filter(e => e.id !== newEffect.id)
  }, 3000)
}

// 随机颜色
const getRandomColor = () => {
  const colors = [
    '#FF6B6B', '#4ECDC4', '#FFD166', '#06D6A0',
    '#118AB2', '#EF476F', '#FFD166', '#06D6A0'
  ]
  return colors[Math.floor(Math.random() * colors.length)]
}

// 2. 背景云朵动画
const cloud1Style = ref({})
const cloud2Style = ref({})
const cloud3Style = ref({})

const initClouds = () => {
  cloud1Style.value = {
    top: '20%',
    left: '10%',
    fontSize: '40px',
    animationDuration: '30s'
  }

  cloud2Style.value = {
    top: '40%',
    left: '30%',
    fontSize: '60px',
    animationDuration: '40s'
  }

  cloud3Style.value = {
    top: '60%',
    left: '50%',
    fontSize: '50px',
    animationDuration: '35s'
  }
}

// 3. 开发环境标识
const isDev = ref(false)

// ========== 原有代码 ==========

// 生命周期
onMounted(async () => {
  // 检测开发环境
  isDev.value = import.meta.env.DEV

  // 初始化云朵动画
  initClouds()

  await initializeGame()
  await nextTick()
  initializeMusic()
})

onUnmounted(() => {
  disconnectWebSocket()
  stopMusic()
})

// 音乐控制方法
const initializeMusic = () => {
  const bgMusic = bgMusicRef.value
  if (!bgMusic) return

  bgMusic.volume = 0.3
  isMusicMuted.value = false

  const savedMusicState = localStorage.getItem('mario-music-state')
  if (savedMusicState === 'muted') {
    isMusicMuted.value = true
    bgMusic.volume = 0
  }

  if (currentScreen.value === 'auth' || currentScreen.value === 'game') {
    if (!isMusicMuted.value) {
      playMusic()
    }
  }
}

const playMusic = () => {
  const bgMusic = bgMusicRef.value
  if (!bgMusic) return

  bgMusic.play().catch(error => {
    console.log('自动播放被阻止，等待用户交互...', error)

    const playOnInteraction = () => {
      bgMusic.play().catch(e => {
        console.log('播放失败:', e)
      })
      document.removeEventListener('click', playOnInteraction)
      document.removeEventListener('keydown', playOnInteraction)
      document.removeEventListener('touchstart', playOnInteraction)
    }

    document.addEventListener('click', playOnInteraction, { once: true })
    document.addEventListener('keydown', playOnInteraction, { once: true })
    document.addEventListener('touchstart', playOnInteraction, { once: true })
  })
}

const pauseMusic = () => {
  const bgMusic = bgMusicRef.value
  if (bgMusic && !bgMusic.paused) {
    bgMusic.pause()
  }
}

const stopMusic = () => {
  const bgMusic = bgMusicRef.value
  if (bgMusic) {
    bgMusic.pause()
    bgMusic.currentTime = 0
  }
}

const toggleMusic = () => {
  const bgMusic = bgMusicRef.value
  if (!bgMusic) return

  isMusicMuted.value = !isMusicMuted.value

  if (isMusicMuted.value) {
    bgMusic.volume = 0
    localStorage.setItem('mario-music-state', 'muted')
  } else {
    bgMusic.volume = 0.3
    localStorage.setItem('mario-music-state', 'unmuted')

    if (bgMusic.paused) {
      playMusic()
    }
  }
}

// 游戏方法
const initializeGame = async () => {
  const steps = [
    '正在连接服务器...',
    '加载游戏资源...',
    '初始化游戏引擎...',
    '准备就绪'
  ]

  for (let i = 0; i < steps.length; i++) {
    loadingText.value = steps[i]
    loadingProgress.value = ((i + 1) / steps.length) * 100
    await new Promise(resolve => setTimeout(resolve, 500))
  }

  const savedUser = localStorage.getItem('mario-player')
  if (savedUser) {
    try {
      const userData = JSON.parse(savedUser)
      playerInfo.username = userData.username
      playerInfo.role = userData.role || 'mario'
      playerInfo.avatar = userData.avatar || ''
      playerInfo.isGuest = userData.isGuest || false
      currentScreen.value = 'game'
    } catch (error) {
      currentScreen.value = 'auth'
    }
  } else {
    currentScreen.value = 'auth'
  }

  connectWebSocket({
    onOpen: () => {
      serverStatus.connected = true
      serverStatus.text = '服务器已连接'
    },
    onClose: () => {
      serverStatus.connected = false
      serverStatus.text = '服务器断开连接'
    },
    onMessage: handleWebSocketMessage
  })
}

const handleLogin = async (username) => {
  playerInfo.username = username
  playerInfo.isGuest = false
  savePlayerInfo()
  currentScreen.value = 'game'

  if (!isMusicMuted.value) {
    playMusic()
  }
}

const handleGuestLogin = () => {
  playerInfo.username = `游客_${Math.floor(Math.random() * 10000)}`
  playerInfo.isGuest = true
  savePlayerInfo()
  currentScreen.value = 'game'

  if (!isMusicMuted.value) {
    playMusic()
  }
}

const showPauseMenu = () => {
  showPauseModal.value = true
  gameState.paused = true
  pauseMusic()
}

const resumeGame = () => {
  showPauseModal.value = false
  gameState.paused = false
  if (!isMusicMuted.value) {
    playMusic()
  }
}

const backToMenu = () => {
  showPauseModal.value = false
  currentScreen.value = 'auth'
  pauseMusic()
}

const handleWebSocketMessage = (message) => {
  switch (message.type) {
    case 'welcome':
      console.log('Welcome message:', message)
      break
    case 'gameState':
      console.log('Game state update:', message)
      break
    default:
      console.log('Unknown message type:', message)
  }
}

const savePlayerInfo = () => {
  localStorage.setItem('mario-player', JSON.stringify(playerInfo))
}
</script>

<style>
@import url('./style.css');
@import url('https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css');

#app {
  width: 100%;
  height: 100vh;
  overflow: hidden;
  position: relative;
  background: linear-gradient(to bottom, #87CEEB 0%, #E0F7FF 100%);
  cursor: default;
}

/* 背景云朵 */
.background-clouds {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  pointer-events: none;
  z-index: 1;
}

.cloud {
  position: absolute;
  opacity: 0.7;
  animation: cloudMove linear infinite;
  user-select: none;
}

@keyframes cloudMove {
  from { transform: translateX(-100px); }
  to { transform: translateX(calc(100vw + 100px)); }
}

/* 点击特效 */
.click-effects {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  pointer-events: none;
  z-index: 999;
}

.click-effect {
  position: absolute;
  pointer-events: none;
  animation: clickEffect 1.5s ease-out forwards;
  font-size: 24px;
  text-shadow: 0 0 10px white;
}

@keyframes clickEffect {
  0% {
    transform: translateY(0) scale(1);
    opacity: 1;
  }
  100% {
    transform: translateY(-100px) scale(1.5);
    opacity: 0;
  }
}

/* 游戏统计信息（只在开发环境显示） */
.game-stats {
  position: fixed;
  top: 70px;
  right: 20px;
  background: rgba(0, 0, 0, 0.7);
  color: white;
  padding: 10px 15px;
  border-radius: 8px;
  font-size: 12px;
  z-index: 999;
  border-left: 4px solid #ffcc00;
}

.game-stats div {
  margin: 3px 0;
  font-family: monospace;
}

/* 音乐控制按钮样式 */
.music-control {
  position: fixed;
  top: 20px;
  right: 20px;
  width: 40px;
  height: 40px;
  border-radius: 50%;
  background: rgba(0, 0, 0, 0.7);
  border: 2px solid #ffcc00;
  color: #ffcc00;
  font-size: 18px;
  cursor: pointer;
  z-index: 1000;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: all 0.3s ease;
}

.music-control:hover {
  background: rgba(0, 0, 0, 0.9);
  transform: scale(1.1);
}

.music-control.muted {
  color: #999;
  border-color: #999;
}

.music-control.muted:hover {
  color: #ffcc00;
  border-color: #ffcc00;
}

/* 隐藏音频元素 */
audio {
  display: none;
}
</style>