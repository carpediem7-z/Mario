/**
 * 游戏API接口封装 - 适配你的后端
 */
class GameAPI {
    constructor() {
        this.baseURL = 'http://localhost:8080/api';
        this.headers = {
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        };
    }

    async request(endpoint, options = {}) {
        const url = `${this.baseURL}${endpoint}`;
        
        const config = {
            ...options,
            headers: {
                ...this.headers,
                ...options.headers
            }
        };
        
        try {
            const response = await fetch(url, config);
            return this.handleResponse(response);
        } catch (error) {
            console.error('API请求失败:', error);
            throw new Error(`网络请求失败: ${error.message}`);
        }
    }

    async handleResponse(response) {
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}`);
        }
        
        try {
            return await response.json();
        } catch (error) {
            return { success: false, message: '响应格式错误' };
        }
    }

    // ============ 游戏场景API ============
    async getAllScenes() {
        return this.request('/scene/all');
    }

    async getScene(sceneId) {
        return this.request(`/scene/${sceneId}`);
    }

    // ============ 玩家API ============
    async getPlayer(playerId) {
        return this.request(`/player/${playerId}`);
    }

    async changePlayerRole(playerId, role) {
        return this.request(`/player/${playerId}/role`, {
            method: 'PUT',
            body: JSON.stringify({ role })
        });
    }

    // ============ 图片API ============
    async loadImage(imageName) {
        try {
            const response = await fetch(`${this.baseURL}/images/${imageName}`);
            if (!response.ok) throw new Error('图片加载失败');
            
            const blob = await response.blob();
            return new Promise((resolve, reject) => {
                const url = URL.createObjectURL(blob);
                const img = new Image();
                img.onload = () => {
                    URL.revokeObjectURL(url);
                    resolve(img);
                };
                img.onerror = reject;
                img.src = url;
            });
        } catch (error) {
            console.warn('加载图片失败:', imageName);
            return this.createPlaceholderImage(imageName);
        }
    }

    createPlaceholderImage(name) {
        const canvas = document.createElement('canvas');
        canvas.width = 64;
        canvas.height = 64;
        const ctx = canvas.getContext('2d');
        
        let color = '#666';
        if (name.includes('bg')) color = '#87CEEB';
        if (name.includes('mario')) color = '#FF0000';
        if (name.includes('brick')) color = '#8B4513';
        if (name.includes('fungus')) color = '#FF69B4';
        
        ctx.fillStyle = color;
        ctx.fillRect(0, 0, 64, 64);
        
        ctx.fillStyle = 'white';
        ctx.font = '10px Arial';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(name.split('.')[0], 32, 32);
        
        return canvas;
    }

    // ============ 连接测试 ============
    async testConnection() {
        try {
            const startTime = Date.now();
            // 简单的连接测试，不依赖房间API
            const response = await fetch(`${this.baseURL}/scene/all`);
            if (!response.ok) throw new Error('连接测试失败');
            const latency = Date.now() - startTime;
            
            return {
                connected: true,
                latency,
                server: this.baseURL
            };
        } catch (error) {
            return {
                connected: false,
                latency: null,
                error: error.message,
                server: this.baseURL
            };
        }
    }
}

// 创建全局API实例
const api = new GameAPI();
window.api = api;