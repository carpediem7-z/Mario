import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'

export default defineConfig({
  plugins: [vue()],
  server: {
    proxy: {
      '/api': {
        target: 'http://localhost:8080', // 你的后端服务器地址
        changeOrigin: true
      },
      '/ws': {
        target: 'ws://localhost:8080', // WebSocket 代理
        ws: true,
        changeOrigin: true
      },
      '/images': {
        target: 'http://localhost:8080', // 图片资源代理
        changeOrigin: true
      }
    }
  }
})