/**
 * 资源管理器
 */
class ResourceManager {
    constructor() {
        this.images = {};
        this.loaded = false;
        this.useFallback = true; // 直接使用回退方案，避免图片加载问题
    }

    async loadAll() {
        if (this.loaded) return;
        
        console.log('开始加载游戏资源...');
        
        // 直接使用回退方案，不尝试加载图片
        console.log('使用回退绘制方案');
        
        this.loaded = true;
        console.log('资源加载完成');
    }

    getMarioSprite(player) {
        // 总是返回null，使用回退绘制
        return null;
    }
    
    getObstacleImage(type) {
        // 总是返回null，使用回退绘制
        return null;
    }
}

/**
 * 多人游戏引擎
 */
class GameEngine {
    constructor() {
        this.canvas = null;
        this.ctx = null;
        this.isRunning = false;
        this.players = {};
        this.scene = null;
        this.resources = new ResourceManager();
        
        // 物理参数
        this.gravity = 980; // 像素/秒²
        this.groundLevel = 400; // 地面高度（站在棕色地面上）
        this.playerSpeed = 250; // 像素/秒
        
        // 玩家ID映射（用于WebSocket更新后的玩家ID同步）
        this.playerIdMap = new Map();
        
        this.init();
    }

    async init() {
        this.canvas = document.getElementById('game-canvas');
        if (!this.canvas) {
            console.error('找不到游戏画布元素');
            return;
        }
        
        this.ctx = this.canvas.getContext('2d');
        this.resizeCanvas();
        
        window.addEventListener('resize', () => this.resizeCanvas());
        
        console.log('游戏引擎初始化...');
        console.log('画布尺寸:', this.canvas.width, 'x', this.canvas.height);
        
        // 先设置默认场景
        this.createDefaultScene();
        
        // 异步加载资源，不阻塞游戏启动
        setTimeout(async () => {
            try {
                await this.resources.loadAll();
                console.log('游戏资源加载完成');
            } catch (error) {
                console.warn('资源加载失败，使用回退样式:', error);
            }
        }, 0);
        
        console.log('多人游戏引擎初始化完成');
    }

    resizeCanvas() {
        if (!this.canvas || !this.canvas.parentElement) return;
        
        const container = this.canvas.parentElement;
        const width = container.clientWidth;
        const height = container.clientHeight;
        
        const gameRatio = 800 / 600;
        const containerRatio = width / height;
        
        let canvasWidth, canvasHeight;
        
        if (containerRatio > gameRatio) {
            canvasHeight = height;
            canvasWidth = height * gameRatio;
        } else {
            canvasWidth = width;
            canvasHeight = width / gameRatio;
        }
        
        // 确保最小尺寸
        canvasWidth = Math.max(canvasWidth, 400);
        canvasHeight = Math.max(canvasHeight, 300);
        
        this.canvas.width = canvasWidth;
        this.canvas.height = canvasHeight;
        
        this.scaleX = canvasWidth / 800;
        this.scaleY = canvasHeight / 600;
        
        console.log(`画布尺寸: ${canvasWidth}x${canvasHeight}, 缩放: ${this.scaleX.toFixed(2)}x${this.scaleY.toFixed(2)}`);
    }

    createDefaultScene() {
        this.scene = {
            sceneId: 'default',
            obstacles: this.createDefaultObstacles(),
            enemies: []
        };
    }

    createDefaultObstacles() {
        const obstacles = [];
        
        // 地板
        for (let i = 0; i < 27; i++) {
            obstacles.push({ x: i * 30, y: 420, type: 1, width: 30, height: 30 });
        }
        
        // 砖块
        for (let i = 3; i < 8; i++) {
            obstacles.push({ x: i * 30, y: 300, type: 0, width: 30, height: 30 });
        }
        
        // 旗子
        obstacles.push({ x: 750, y: 220, type: 8, width: 30, height: 200 });
        
        return obstacles;
    }

    startGame(playerName) {
        if (this.isRunning) {
            console.log('游戏已经在运行中');
            return;
        }
        
        this.isRunning = true;
        this.lastTime = performance.now();
        
        console.log('=== 游戏开始 ===');
        console.log('画布尺寸:', this.canvas.width, this.canvas.height);
        console.log('玩家信息:', window.gameApp?.player);
        
        // 确保至少有当前玩家
        const currentPlayer = window.gameApp?.player;
        if (currentPlayer) {
            console.log('添加当前玩家到游戏...');
            this.updatePlayerData({
                id: currentPlayer.id,
                name: playerName,
                x: 100,
                y: this.groundLevel,
                role: currentPlayer.role || 'mario',
                status: 'stand--right',
                velocityX: 0,
                velocityY: 0,
                isJumping: false,
                onGround: true,
                direction: 'right'
            });
        } else {
            console.warn('没有玩家信息，创建测试玩家');
            // 创建一个测试玩家
            this.updatePlayerData({
                id: 'test_player_001',
                name: '测试玩家',
                x: 100,
                y: this.groundLevel,
                role: 'mario',
                status: 'stand--right'
            });
        }
        
        console.log('当前游戏中的玩家:', Object.keys(this.players));
        if (Object.keys(this.players).length > 0) {
            const player = this.players[Object.keys(this.players)[0]];
            console.log('第一个玩家详情:', player);
        }
        
        // 启动游戏循环
        this.gameLoop();
        console.log('游戏开始运行');
    }

    pause() {
        this.isRunning = false;
    }

    resume() {
        if (this.isRunning) return;
        
        this.isRunning = true;
        this.lastTime = performance.now();
        this.gameLoop();
    }

    stop() {
        this.isRunning = false;
        this.players = {};
        this.playerIdMap.clear();
    }

    gameLoop(currentTime = 0) {
        if (!this.isRunning) return;
        
        if (!this.lastTime) this.lastTime = currentTime;
        const deltaTime = (currentTime - this.lastTime) / 1000;
        this.lastTime = currentTime;
        
        this.update(deltaTime);
        this.render();
        
        requestAnimationFrame((time) => this.gameLoop(time));
    }

    update(deltaTime) {
        // 更新所有玩家物理状态
        Object.values(this.players).forEach(player => {
            this.updatePlayerPhysics(player, deltaTime);
        });
    }

    updatePlayerPhysics(player, deltaTime) {
        // 应用水平移动
        if (player.velocityX !== 0) {
            player.x += player.velocityX * deltaTime;
            player.x = Math.max(0, Math.min(775, player.x));
        }
        
        // 应用重力
        if (!player.onGround || player.isJumping) {
            player.velocityY += this.gravity * deltaTime;
            player.y += player.velocityY * deltaTime;
            
            // 落地检测
            if (player.y >= this.groundLevel) {
                player.y = this.groundLevel;
                player.velocityY = 0;
                player.isJumping = false;
                player.onGround = true;
                
                // 更新状态为站立
                if (player.status.includes('jump')) {
                    player.status = player.direction === 'left' ? 'stand--left' : 'stand--right';
                }
            }
        }
    }

    render() {
        if (!this.ctx) {
            console.error('Canvas context is null');
            return;
        }
        
        // 检查画布是否有效
        if (this.canvas.width === 0 || this.canvas.height === 0) {
            console.error('画布尺寸为0');
            this.resizeCanvas();
        }
        
        // 清除画布
        this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
        
        // 绘制背景
        this.drawBackground();
        
        // 绘制场景
        if (this.scene) {
            this.drawScene();
        }
        
        // 调试信息
        if (Object.keys(this.players).length === 0) {
            this.ctx.fillStyle = 'red';
            this.ctx.font = '20px Arial';
            this.ctx.textAlign = 'center';
            this.ctx.fillText('没有玩家数据！', this.canvas.width/2, this.canvas.height/2);
            console.log('渲染：没有玩家数据');
        } else {
            console.log(`渲染中... 玩家数量: ${Object.keys(this.players).length}`);
            this.drawPlayers();
        }
    }

    drawBackground() {
        // 简单背景，确保可见
        const gradient = this.ctx.createLinearGradient(0, 0, 0, this.canvas.height);
        gradient.addColorStop(0, '#87CEEB');
        gradient.addColorStop(1, '#E0F7FA');
        
        this.ctx.fillStyle = gradient;
        this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);
        
        // 绘制地面指示线
        this.ctx.fillStyle = 'rgba(0, 255, 0, 0.3)';
        const groundY = this.groundLevel * this.scaleY;
        this.ctx.fillRect(0, groundY, this.canvas.width, 2);
    }

    drawScene() {
        if (!this.scene || !this.scene.obstacles) return;
        
        this.scene.obstacles.forEach(obstacle => {
            this.drawObstacle(obstacle);
        });
    }

    drawObstacle(obstacle) {
        const x = obstacle.x * this.scaleX;
        const y = obstacle.y * this.scaleY;
        const width = (obstacle.width || 30) * this.scaleX;
        const height = (obstacle.height || 30) * this.scaleY;
        
        // 回退方案：使用颜色
        let color;
        switch (obstacle.type) {
            case 0: color = '#8B4513'; break; // 砖块 - 棕色
            case 1: color = '#228B22'; break; // 地面 - 绿色
            case 8: color = '#FF0000'; break; // 旗子 - 红色
            default: color = '#A0522D';
        }
        
        this.ctx.fillStyle = color;
        this.ctx.fillRect(x, y, width, height);
        
        this.ctx.strokeStyle = 'rgba(0, 0, 0, 0.3)';
        this.ctx.lineWidth = 1;
        this.ctx.strokeRect(x, y, width, height);
    }

    drawPlayers() {
        const playerCount = Object.keys(this.players).length;
        console.log(`绘制玩家，总数: ${playerCount}`);
        
        if (playerCount === 0) {
            this.ctx.fillStyle = 'red';
            this.ctx.font = '20px Arial';
            this.ctx.textAlign = 'center';
            this.ctx.fillText('没有玩家！', this.canvas.width/2, this.canvas.height/2);
            return;
        }
        
        Object.values(this.players).forEach((player, index) => {
            console.log(`绘制玩家 ${index + 1}:`, player.name, `位置: (${player.x}, ${player.y})`);
            this.drawPlayer(player);
        });
    }

    drawPlayer(player) {
        if (!player) {
            console.warn('尝试绘制空的玩家对象');
            return;
        }
        
        // 检查位置是否有效
        if (player.x === undefined || player.y === undefined) {
            console.warn(`玩家 ${player.name} 位置无效: (${player.x}, ${player.y})`);
            player.x = 50;
            player.y = this.groundLevel;
        }
        
        const x = player.x * this.scaleX;
        const y = player.y * this.scaleY;
        const size = 30 * this.scaleX;
        
        console.log(`转换玩家 ${player.name}: 原始(${player.x}, ${player.y}) -> 屏幕(${x.toFixed(1)}, ${y.toFixed(1)})`);
        
        // 确保位置在画布内
        if (x < -size || x > this.canvas.width + size || y < -size || y > this.canvas.height + size) {
            console.warn(`玩家 ${player.name} 位置超出画布: (${x}, ${y})`);
            return;
        }
        
        // 使用简单方块确保可见
        this.drawPlayerFallback(player, x, y, size);
        
        // 调试信息：显示坐标
        if (this.isRunning) {
            this.ctx.fillStyle = '#FFFF00';
            this.ctx.font = '12px Arial';
            this.ctx.textAlign = 'center';
            this.ctx.fillText(`${Math.round(player.x)},${Math.round(player.y)}`, x + size/2, y + size + 20);
        }
    }

    // 绘制玩家回退方案
    drawPlayerFallback(player, x, y, size) {
        // 根据角色设置颜色
        let color;
        switch (player.role) {
            case 'mario': color = '#FF0000'; break; // 红色
            case 'luigi': color = '#00FF00'; break; // 绿色
            default: color = '#FFA500'; // 橙色
        }
        
        // 绘制身体
        this.ctx.fillStyle = color;
        this.ctx.fillRect(x, y, size, size);
        
        // 绘制帽子
        this.ctx.fillStyle = '#FFD700';
        this.ctx.fillRect(x, y - size * 0.2, size, size * 0.3);
        
        // 绘制面部
        this.ctx.fillStyle = 'white';
        this.ctx.beginPath();
        this.ctx.arc(x + size * 0.3, y + size * 0.3, size * 0.15, 0, Math.PI * 2);
        this.ctx.arc(x + size * 0.7, y + size * 0.3, size * 0.15, 0, Math.PI * 2);
        this.ctx.fill();
        
        this.ctx.fillStyle = 'black';
        this.ctx.beginPath();
        this.ctx.arc(x + size * 0.3, y + size * 0.3, size * 0.05, 0, Math.PI * 2);
        this.ctx.arc(x + size * 0.7, y + size * 0.3, size * 0.05, 0, Math.PI * 2);
        this.ctx.fill();
        
        // 绘制嘴巴
        this.ctx.beginPath();
        this.ctx.arc(x + size * 0.5, y + size * 0.7, size * 0.2, 0, Math.PI);
        this.ctx.stroke();
        
        // 绘制玩家名字
        this.ctx.fillStyle = 'white';
        this.ctx.font = `bold ${Math.max(12, size * 0.25)}px Arial`;
        this.ctx.textAlign = 'center';
        this.ctx.strokeStyle = 'black';
        this.ctx.lineWidth = 3;
        this.ctx.strokeText(player.name, x + size/2, y - 10);
        this.ctx.fillText(player.name, x + size/2, y - 10);
        
        // 标记当前玩家
        if (this.isRunning && player.id === window.gameApp?.player?.id) {
            this.ctx.fillStyle = '#FFFF00';
            this.ctx.font = `bold ${Math.max(14, size * 0.3)}px Arial`;
            this.ctx.fillText('★', x + size/2, y - 30);
        }
    }

    movePlayer(playerId, direction) {
        const player = this.players[playerId];
        if (!player) {
            console.warn(`无法移动玩家: ${playerId} 不存在`);
            return;
        }
        
        console.log(`移动玩家 ${player.name}: ${direction}`);
        
        switch (direction) {
            case 'LEFT':
                player.velocityX = -this.playerSpeed;
                player.status = 'move--left';
                player.direction = 'left';
                break;
            case 'RIGHT':
                player.velocityX = this.playerSpeed;
                player.status = 'move--right';
                player.direction = 'right';
                break;
            case 'STOP':
                player.velocityX = 0;
                if (player.onGround && !player.isJumping) {
                    player.status = player.direction === 'left' ? 'stand--left' : 'stand--right';
                }
                break;
        }
        
        console.log(`玩家 ${player.name} 新状态: ${player.status}, 速度: ${player.velocityX}`);
    }

    jumpPlayer(playerId) {
        const player = this.players[playerId];
        if (!player) {
            console.warn(`无法跳跃: 玩家 ${playerId} 不存在`);
            return;
        }
        
        if (player.isJumping || !player.onGround) {
            console.log(`玩家 ${player.name} 已经在跳跃中或不在地面`);
            return;
        }
        
        console.log(`玩家 ${player.name} 跳跃`);
        
        player.velocityY = -600; // 增加跳跃初速度，让跳跃高度更明显
        player.isJumping = true;
        player.onGround = false;
        player.status = player.direction === 'left' ? 'jump--left' : 'jump--right';
    }

    updatePlayerData(playerData) {
        // 验证playerData是否有效
        if (!playerData || !playerData.id) {
            console.warn('无效的玩家数据:', playerData);
            return;
        }
        
        const playerId = playerData.id;
        
        // 检查是否是系统字段（如type, roomId等）
        if (['type', 'roomId', 'roomName', 'timestamp', 'players', 'roomInfo'].includes(playerId)) {
            console.log('忽略系统字段作为玩家:', playerId);
            return;
        }
        
        // 检查是否是欢迎消息中的字段
        if (playerData.playerName && !playerData.name) {
            playerData.name = playerData.playerName;
        }
        
        if (!this.players[playerId]) {
            // 新玩家
            this.players[playerId] = {
                id: playerId,
                name: playerData.name || '玩家',
                role: playerData.role || 'mario',
                x: playerData.x || 50,
                y: playerData.y || this.groundLevel,
                velocityX: 0,
                velocityY: 0,
                status: playerData.status || 'stand--right',
                score: playerData.score || 0,
                isJumping: false,
                onGround: true,
                direction: playerData.direction || 'right'
            };
            
            console.log(`新玩家加入游戏: ${playerData.name || playerId} (${playerId})`);
            console.log('玩家详情:', this.players[playerId]);
        } else {
            // 更新玩家（来自服务器同步）
            if (playerData.x !== undefined) {
                console.log(`更新玩家 ${player.name} 位置: ${this.players[playerId].x} -> ${playerData.x}`);
                this.players[playerId].x = playerData.x;
            }
            if (playerData.y !== undefined) {
                console.log(`更新玩家 ${player.name} Y位置: ${this.players[playerId].y} -> ${playerData.y}`);
                this.players[playerId].y = playerData.y;
            }
            if (playerData.status) {
                console.log(`更新玩家 ${player.name} 状态: ${this.players[playerId].status} -> ${playerData.status}`);
                this.players[playerId].status = playerData.status;
                if (playerData.status.includes('left')) {
                    this.players[playerId].direction = 'left';
                } else if (playerData.status.includes('right')) {
                    this.players[playerId].direction = 'right';
                }
            }
            if (playerData.role) this.players[playerId].role = playerData.role;
            if (playerData.score !== undefined) this.players[playerId].score = playerData.score;
            
            // 更新物理状态
            if (playerData.status && playerData.status.includes('jump')) {
                this.players[playerId].isJumping = true;
                this.players[playerId].onGround = false;
            }
        }
        
        console.log('当前所有玩家:', Object.keys(this.players));
    }

    // 新增：更新玩家ID（用于WebSocket更新后的玩家ID同步）
    updatePlayerId(oldId, newId) {
        if (!this.players[oldId]) {
            console.log(`无法更新玩家ID: 原ID ${oldId} 不存在`);
            return;
        }
        
        console.log(`更新玩家ID映射: ${oldId} -> ${newId}`);
        
        // 保存映射关系
        this.playerIdMap.set(oldId, newId);
        
        // 转移玩家数据
        this.players[newId] = this.players[oldId];
        this.players[newId].id = newId;
        
        // 删除旧的玩家数据
        delete this.players[oldId];
        
        console.log('更新后的玩家列表:', Object.keys(this.players));
    }

    removePlayer(playerId) {
        if (this.players[playerId]) {
            console.log(`玩家离开游戏: ${this.players[playerId].name} (${playerId})`);
            delete this.players[playerId];
        }
        
        // 清理映射
        this.playerIdMap.delete(playerId);
        
        console.log('剩余玩家:', Object.keys(this.players));
    }
}

// 导出游戏引擎
window.GameEngine = GameEngine;