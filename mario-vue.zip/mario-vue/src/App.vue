<template>
  <div id="app">
    <!-- 加载屏幕 -->
    <LoadingScreen 
      v-if="currentScreen === 'loading'" 
      :progress="loadingProgress"
      :text="loadingText"
    />
    
    <!-- 登录/注册界面 -->
    <AuthScreen 
      v-else-if="currentScreen === 'auth'"
      :server-status="serverStatus"
      @login="handleLogin"
      @guest-login="handleGuestLogin"
    />
    
    <!-- 游戏屏幕 -->
    <GameScreen 
      v-else-if="currentScreen === 'game'"
      :player-info="playerInfo"
      :game-state="gameState"
      @pause="showPauseMenu"
      @back-to-menu="backToMenu"
    />
    
    <!-- 暂停菜单模态框 -->
    <PauseModal 
      v-if="showPauseModal"
      @resume="resumeGame"
      @back-menu="backToMenu"
    />
  </div>
</template>

<script setup>
import { ref, reactive, onMounted, onUnmounted } from 'vue'
import LoadingScreen from './components/LoadingScreen.vue'
import AuthScreen from './components/AuthScreen.vue'
import GameScreen from './components/GameScreen.vue'
import PauseModal from './components/PauseModal.vue'
import { connectWebSocket, disconnectWebSocket } from './utils/websocket'

// 状态管理
const currentScreen = ref('loading')
const loadingProgress = ref(0)
const loadingText = ref('正在连接服务器...')
const serverStatus = reactive({
  connected: false,
  text: '正在检测服务器...'
})
const playerInfo = reactive({
  username: '',
  role: 'mario',
  avatar: '',
  isGuest: false
})
const gameState = reactive({
  score: 0,
  health: 3,
  paused: false
})
const showPauseModal = ref(false)

// 生命周期
onMounted(() => {
  initializeGame()
})

onUnmounted(() => {
  disconnectWebSocket()
})

// 方法
const initializeGame = async () => {
  // 模拟加载过程
  const steps = [
    '正在连接服务器...',
    '加载游戏资源...',
    '初始化游戏引擎...',
    '准备就绪'
  ]
  
  for (let i = 0; i < steps.length; i++) {
    loadingText.value = steps[i]
    loadingProgress.value = ((i + 1) / steps.length) * 100
    await new Promise(resolve => setTimeout(resolve, 500))
  }
  
  // 检查本地存储的用户信息
  const savedUser = localStorage.getItem('mario-player')
  if (savedUser) {
    try {
      const userData = JSON.parse(savedUser)
      playerInfo.username = userData.username
      playerInfo.role = userData.role || 'mario'
      playerInfo.avatar = userData.avatar || ''
      playerInfo.isGuest = userData.isGuest || false
      currentScreen.value = 'game'
    } catch (error) {
      currentScreen.value = 'auth'
    }
  } else {
    currentScreen.value = 'auth'
  }
  
  // 连接 WebSocket
  connectWebSocket({
    onOpen: () => {
      serverStatus.connected = true
      serverStatus.text = '服务器已连接'
    },
    onClose: () => {
      serverStatus.connected = false
      serverStatus.text = '服务器断开连接'
    },
    onMessage: handleWebSocketMessage
  })
}

const handleLogin = async (username) => {
  playerInfo.username = username
  playerInfo.isGuest = false
  savePlayerInfo()
  currentScreen.value = 'game'
}

const handleGuestLogin = () => {
  playerInfo.username = `游客_${Math.floor(Math.random() * 10000)}`
  playerInfo.isGuest = true
  savePlayerInfo()
  currentScreen.value = 'game'
}

const handleLogout = () => {
  localStorage.removeItem('mario-player')
  playerInfo.username = ''
  playerInfo.isGuest = false
  currentScreen.value = 'auth'
}

const showPauseMenu = () => {
  showPauseModal.value = true
  gameState.paused = true
}

const resumeGame = () => {
  showPauseModal.value = false
  gameState.paused = false
}

const backToMenu = () => {
  showPauseModal.value = false
  currentScreen.value = 'auth'
}

const handleWebSocketMessage = (message) => {
  switch (message.type) {
    case 'welcome':
      console.log('Welcome message:', message)
      break
    case 'gameState':
      console.log('Game state update:', message)
      break
    default:
      console.log('Unknown message type:', message)
  }
}

const savePlayerInfo = () => {
  localStorage.setItem('mario-player', JSON.stringify(playerInfo))
}
</script>

<style>
@import url('./style.css');
@import url('https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css');

#app {
  width: 100%;
  height: 100vh;
  overflow: hidden;
}
</style>