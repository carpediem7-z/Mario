<template>
  <div class="screen">
    <!-- 开始游戏屏幕 -->
    <div v-if="!gameStarted" class="start-game-screen">
      <div class="start-game-content">
        <h1>马里奥游戏</h1>
        <p>经典单人冒险</p>
        <button @click="startGame" class="start-button">开始游戏</button>
      </div>
    </div>
    
    <!-- HUD -->
    <div v-if="gameStarted" class="hud">
      <div class="hud-left">
        <div class="score-display">
          <i class="fas fa-star"></i>
          <span>分数: {{ marioScore }}</span>
        </div>
      </div>
      <div class="hud-right">
        <div class="health-display">
          <div class="hearts">
            <i v-for="i in 3" :key="i" class="fas fa-heart" :class="{ 'heart-lost': i > gameState.health }"></i>
          </div>
        </div>
      </div>
    </div>
    
    <!-- 游戏画布 -->
    <div class="game-container">
      <canvas ref="gameCanvas"></canvas>
    </div>
    
    <!-- 游戏结束屏幕 -->
    <div v-if="gameOver" class="game-over-screen">
      <div class="game-over-content">
        <h1>游戏结束</h1>
        <p>你的得分: {{ marioScore }}</p>
        <button @click="restartGame">重新开始</button>
      </div>
    </div>
    
    <!-- 游戏胜利屏幕 -->
    <div v-if="gameWon" class="game-won-screen">
      <div class="game-won-content">
        <h1>游戏胜利</h1>
        <p>你的得分: {{ marioScore }}</p>
        <button @click="restartGame">重新开始</button>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, onUnmounted, defineProps, defineEmits } from 'vue'
import { connectWebSocket, disconnectWebSocket, sendMessage, addMessageHandler } from '../utils/websocket'

const props = defineProps({
  playerInfo: Object,
  gameState: {
    type: Object,
    default: () => ({
      score: 0,
      health: 3,
      paused: false
    })
  }
})

// 图片资源
const backgroundImage = ref(new Image())
const backgroundImage2 = ref(new Image())
const marioStandRight = ref(new Image())
const marioStandLeft = ref(new Image())
const marioRunRight1 = ref(new Image())
const marioRunRight2 = ref(new Image())
const marioRunLeft1 = ref(new Image())
const marioRunLeft2 = ref(new Image())
const marioJumpRight = ref(new Image())
const marioJumpLeft = ref(new Image())

// 障碍物图片
const brickImage = ref(new Image())
const brick2Image = ref(new Image())
const pipe1Image = ref(new Image())
const pipe2Image = ref(new Image())
const pipe3Image = ref(new Image())
const pipe4Image = ref(new Image())
const soilBaseImage = ref(new Image())
const soilUpImage = ref(new Image())

// 小怪图片
const fungus1Image = ref(new Image())
const fungus2Image = ref(new Image())
const fungus3Image = ref(new Image())
const flower1Image = ref(new Image())
const flower2Image = ref(new Image())

// 场景元素
const towerImage = ref(new Image())
const ganImage = ref(new Image())
const flagImage = ref(new Image())

// 小怪状态
const enemies = ref([
  { id: 1, x: 580, y: 385, width: 40, height: 40, direction: 1, speed: 0.5, alive: true, type: 1, frame: 0 }, // 蘑菇敌人
  { id: 2, x: 635, y: 420, width: 40, height: 40, direction: -1, speed: 0.5, alive: true, type: 2, frame: 0, minY: 328, maxY: 428 }  // 食人花敌人，移动范围328-428
])

// 障碍物状态
const obstacles = ref([])

// 初始化第一关地图
const initLevel1Map = () => {
  obstacles.value = []
  
  // 地板
  for (let i = 0; i < 27; i++) {
    obstacles.value.push({ id: obstacles.value.length + 1, x: i * 30, y: 420, width: 30, height: 30, type: 1 }) // 地板砖
  }
  
  // 底部土壤
  for (let j = 0; j <= 120; j += 30) {
    for (let i = 0; i < 27; i++) {
      obstacles.value.push({ id: obstacles.value.length + 1, x: i * 30, y: 570 - j, width: 30, height: 30, type: 2 }) // 土壤
    }
  }
  
  // 砖块A
  for (let i = 120; i <= 150; i += 30) {
    obstacles.value.push({ id: obstacles.value.length + 1, x: i, y: 300, width: 30, height: 30, type: 7 }) // 空砖块
  }
  
  // 砖块B-F
  for (let i = 300; i <= 570; i += 30) {
    if (i === 360 || i === 390 || i === 480 || i === 510 || i === 540) {
      obstacles.value.push({ id: obstacles.value.length + 1, x: i, y: 300, width: 30, height: 30, type: 7 }) // 空砖块
    } else {
      obstacles.value.push({ id: obstacles.value.length + 1, x: i, y: 300, width: 30, height: 30, type: 0 }) // 可破坏砖块
    }
  }
  
  // 砖块G
  for (let i = 420; i <= 450; i += 30) {
    obstacles.value.push({ id: obstacles.value.length + 1, x: i, y: 240, width: 30, height: 30, type: 7 }) // 空砖块
  }
  
  // 水管
  for (let i = 360; i <= 600; i += 25) {
    if (i === 360) {
      obstacles.value.push({ id: obstacles.value.length + 1, x: 620, y: i, width: 25, height: 25, type: 3 }) // 水管头部左
      obstacles.value.push({ id: obstacles.value.length + 1, x: 645, y: i, width: 25, height: 25, type: 4 }) // 水管头部右
    } else {
      obstacles.value.push({ id: obstacles.value.length + 1, x: 620, y: i, width: 25, height: 25, type: 5 }) // 水管身体左
      obstacles.value.push({ id: obstacles.value.length + 1, x: 645, y: i, width: 25, height: 25, type: 6 }) // 水管身体右
    }
  }
}

// 初始化第二关地图
const initLevel2Map = () => {
  obstacles.value = []
  
  // 地板
  for (let i = 0; i < 27; i++) {
    obstacles.value.push({ id: obstacles.value.length + 1, x: i * 30, y: 420, width: 30, height: 30, type: 2 }) // 土壤上
  }
  
  for (let j = 0; j <= 120; j += 30) {
    for (let i = 0; i < 27; i++) {
      obstacles.value.push({ id: obstacles.value.length + 1, x: i * 30, y: 570 - j, width: 30, height: 30, type: 2 }) // 土壤底
    }
  }
  
  // 第一个水管
  for (let i = 360; i <= 600; i += 25) {
    if (i === 360) {
      obstacles.value.push({ id: obstacles.value.length + 1, x: 60, y: i, width: 25, height: 25, type: 3 }) // 水管头部左
      obstacles.value.push({ id: obstacles.value.length + 1, x: 85, y: i, width: 25, height: 25, type: 4 }) // 水管头部右
    } else {
      obstacles.value.push({ id: obstacles.value.length + 1, x: 60, y: i, width: 25, height: 25, type: 5 }) // 水管身体左
      obstacles.value.push({ id: obstacles.value.length + 1, x: 85, y: i, width: 25, height: 25, type: 6 }) // 水管身体右
    }
  }
  
  // 第二个水管
  for (let i = 330; i <= 600; i += 25) {
    if (i === 330) {
      obstacles.value.push({ id: obstacles.value.length + 1, x: 620, y: i, width: 25, height: 25, type: 3 }) // 水管头部左
      obstacles.value.push({ id: obstacles.value.length + 1, x: 645, y: i, width: 25, height: 25, type: 4 }) // 水管头部右
    } else {
      obstacles.value.push({ id: obstacles.value.length + 1, x: 620, y: i, width: 25, height: 25, type: 5 }) // 水管身体左
      obstacles.value.push({ id: obstacles.value.length + 1, x: 645, y: i, width: 25, height: 25, type: 6 }) // 水管身体右
    }
  }
  
  // 砖块C
  obstacles.value.push({ id: obstacles.value.length + 1, x: 300, y: 330, width: 30, height: 30, type: 0 }) // 可破坏砖块
  
  // 砖块BEG
  for (let i = 270; i <= 330; i += 30) {
    if (i === 270 || i === 330) {
      obstacles.value.push({ id: obstacles.value.length + 1, x: i, y: 360, width: 30, height: 30, type: 0 }) // 可破坏砖块
    } else {
      obstacles.value.push({ id: obstacles.value.length + 1, x: i, y: 360, width: 30, height: 30, type: 7 }) // 空砖块
    }
  }
  
  // 砖块ADFHI
  for (let i = 240; i <= 360; i += 30) {
    if (i === 240 || i === 360) {
      obstacles.value.push({ id: obstacles.value.length + 1, x: i, y: 390, width: 30, height: 30, type: 0 }) // 可破坏砖块
    } else {
      obstacles.value.push({ id: obstacles.value.length + 1, x: i, y: 390, width: 30, height: 30, type: 7 }) // 空砖块
    }
  }
  
  // 妨碍砖块1
  obstacles.value.push({ id: obstacles.value.length + 1, x: 240, y: 300, width: 30, height: 30, type: 0 }) // 可破坏砖块
  
  // 空砖块1-4
  for (let i = 360; i <= 540; i += 60) {
    obstacles.value.push({ id: obstacles.value.length + 1, x: i, y: 270, width: 30, height: 30, type: 7 }) // 空砖块
  }
}

// 游戏状态标志
const gameStarted = ref(false)
const flagPulled = ref(false)
const isDescending = ref(false)
const isEnteringCastle = ref(false)
const castleEntered = ref(false)
const flagY = ref(0)

// 初始化第三关地图
const initLevel3Map = () => {
  obstacles.value = []
  flagPulled.value = false
  isDescending.value = false
  isEnteringCastle.value = false
  castleEntered.value = false
  flagY.value = 0 // 初始化旗子Y偏移量为0
  
  // 地板
  for (let i = 0; i < 27; i++) {
    obstacles.value.push({ id: obstacles.value.length + 1, x: i * 30, y: 420, width: 30, height: 30, type: 2 }) // 土壤上
  }
  
  for (let j = 0; j <= 120; j += 30) {
    for (let i = 0; i < 27; i++) {
      obstacles.value.push({ id: obstacles.value.length + 1, x: i * 30, y: 570 - j, width: 30, height: 30, type: 2 }) // 土壤底
    }
  }
  
  // 砖块A-O
  let temp = 290
  for (let i = 390; i >= 270; i -= 30) {
    for (let j = temp; j <= 410; j += 30) {
      obstacles.value.push({ id: obstacles.value.length + 1, x: j, y: i, width: 30, height: 30, type: 7 }) // 空砖块
    }
    temp += 30
  }
  
  // 砖块P-R
  temp = 60
  for (let i = 390; i >= 360; i -= 30) {
    for (let j = temp; j <= 90; j += 30) {
      obstacles.value.push({ id: obstacles.value.length + 1, x: j, y: i, width: 30, height: 30, type: 7 }) // 空砖块
    }
    temp += 30
  }
  
  // 旗杆底座
  for (let i = 0; i < 3; i++) {
    obstacles.value.push({ id: obstacles.value.length + 1, x: 450 + i * 30, y: 420, width: 30, height: 30, type: 7 }) // 空砖块
  }
  
  // 旗杆（使用新的类型）
  obstacles.value.push({ id: obstacles.value.length + 1, x: 495, y: 250, width: 10, height: 170, type: 10 }) // 旗杆
  
  // 旗子
  obstacles.value.push({ id: obstacles.value.length + 1, x: 500, y: 250, width: 30, height: 40, type: 8 }) // 旗子，位于旗杆顶端
  
  // 城堡（位于旗杆右边）
  obstacles.value.push({ id: obstacles.value.length + 1, x: 550, y: 330, width: 80, height: 90, type: 9 }) // 城堡
}

// 初始化地图
onMounted(() => {
  initLevel1Map()
})

const emit = defineEmits(['pause', 'back-to-menu', 'update:playerInfo', 'update:gameState'])

const gameCanvas = ref(null)
let canvasContext = null
let animationFrameId = null
let players = ref([])

// 马里奥状态管理
const marioStatus = ref('stand--right')
const marioIndex = ref(0)
const marioX = ref(10)
const marioY = ref(355)
const marioXSpeed = ref(0)
const marioYSpeed = ref(0)
const marioUpTime = ref(0)
const marioMoved = ref(false)

// 游戏状态管理和得分系统
const marioScore = ref(0)
const marioIsDeath = ref(false)
const marioIsOK = ref(false)
const gameOver = ref(false)
const gameWon = ref(false)

// 当前关卡
const currentLevel = ref(1)
const totalLevels = 3

// 键盘控制
const keys = {
  ArrowLeft: false,
  ArrowRight: false,
  ArrowUp: false
}

// 开始游戏函数
const startGame = () => {
  gameStarted.value = true
  // 如果游戏循环还没有开始，启动它
  if (!animationFrameId) {
    gameLoop()
  }
}

onMounted(() => {
  initCanvas()
  initControls()
  initWebSocket()
  loadImages()
  initLevel1Map()
  
  // 监听键盘事件
  window.addEventListener('keydown', handleKeyDown)
  window.addEventListener('keyup', handleKeyUp)
  
  // 监听游戏暂停事件（如按ESC键）
  window.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      emit('pause')
    }
  })
  
  // 初始化马里奥位置
  if (props.playerInfo) {
    marioX.value = props.playerInfo.x || 10
    marioY.value = props.playerInfo.y || 380
  }
  
  // 绘制初始画面
  draw()
})

const loadImages = () => {
  // 加载背景图片
  backgroundImage.value.src = '/images/bg.png'
  backgroundImage2.value.src = '/images/bg2.png'
  
  // 加载马里奥角色图片
  marioStandRight.value.src = '/images/s_mario_stand_R.png'
  marioStandLeft.value.src = '/images/s_mario_stand_L.png'
  marioRunRight1.value.src = '/images/s_mario_run1_R.png'
  marioRunRight2.value.src = '/images/s_mario_run2_R.png'
  marioRunLeft1.value.src = '/images/s_mario_run1_L.png'
  marioRunLeft2.value.src = '/images/s_mario_run2_L.png'
  marioJumpRight.value.src = '/images/s_mario_jump1_R.png'
  marioJumpLeft.value.src = '/images/s_mario_jump1_L.png'
  
  // 加载障碍物图片
  brickImage.value.src = '/images/brick.png'
  brick2Image.value.src = '/images/brick2.png'
  pipe1Image.value.src = '/images/pipe1.png'
  pipe2Image.value.src = '/images/pipe2.png'
  pipe3Image.value.src = '/images/pipe3.png'
  pipe4Image.value.src = '/images/pipe4.png'
  soilBaseImage.value.src = '/images/soil_base.png'
  soilUpImage.value.src = '/images/soil_up.png'
  
  // 加载小怪图片
  fungus1Image.value.src = '/images/fungus1.png'
  fungus2Image.value.src = '/images/fungus2.png'
  fungus3Image.value.src = '/images/fungus3.png'
  flower1Image.value.src = '/images/flower1.1.png'
  flower2Image.value.src = '/images/flower1.2.png'
  
  // 加载场景元素
  towerImage.value.src = '/images/tower.png'
  ganImage.value.src = '/images/gan.png'
  flagImage.value.src = '/images/flag.png'
  
  // 图片加载完成后重新绘制
  backgroundImage.value.onload = draw
  backgroundImage2.value.onload = draw
  marioStandRight.value.onload = draw
  marioStandLeft.value.onload = draw
  marioRunRight1.value.onload = draw
  marioRunRight2.value.onload = draw
  marioRunLeft1.value.onload = draw
  marioRunLeft2.value.onload = draw
  marioJumpRight.value.onload = draw
  marioJumpLeft.value.onload = draw
  brickImage.value.onload = draw
  brick2Image.value.onload = draw
  pipe1Image.value.onload = draw
  pipe2Image.value.onload = draw
  pipe3Image.value.onload = draw
  pipe4Image.value.onload = draw
  soilBaseImage.value.onload = draw
  soilUpImage.value.onload = draw
  fungus1Image.value.onload = draw
  fungus2Image.value.onload = draw
  fungus3Image.value.onload = draw
  flower1Image.value.onload = draw
  flower2Image.value.onload = draw
  towerImage.value.onload = draw
  ganImage.value.onload = draw
  flagImage.value.onload = draw
}

const initWebSocket = () => {
  connectWebSocket({
    onOpen: () => {
      console.log('WebSocket connected to game server')
    },
    onClose: () => {
      console.log('WebSocket disconnected from game server')
    },
    onMessage: (message) => {
      handleWebSocketMessage(message)
    }
  })
}

onUnmounted(() => {
  window.removeEventListener('keydown', handleKeyDown)
  window.removeEventListener('keyup', handleKeyUp)
  disconnectWebSocket()
  if (animationFrameId) {
    cancelAnimationFrame(animationFrameId)
  }
})

const handleWebSocketMessage = (message) => {
  switch (message.type) {
    case 'welcome':
      console.log('Welcome message:', message)
      // 保存玩家信息到父组件
      if (message.data && message.data.player) {
        emit('update:playerInfo', message.data.player)
      } else if (message.player) {
        // 兼容没有data属性的welcome消息
        emit('update:playerInfo', message.player)
      }
      break
    case 'gameState':
      console.log('Game state update:', message)
      // 更新游戏状态到父组件
      if (message.data && message.data.gameState) {
        emit('update:gameState', message.data.gameState)
      }
      // 更新玩家列表
          // 处理后端可能返回的对象形式的玩家数据
          if (Array.isArray(message.data?.players)) {
            players.value = message.data.players
          } else if (typeof message.data?.players === 'object' && message.data.players !== null) {
            // 如果是对象，转换为数组
            players.value = Object.values(message.data.players)
          } else {
            players.value = []
          }
          console.log('Players updated:', players.value)
          console.log('Player positions:', players.value.map(p => ({id: p.id, x: p.x, y: p.y, direction: p.direction, status: p.status})))
      break
    case 'playerMove':
      console.log('Player move:', message)
      // 更新玩家位置
      if (message.data && message.data.player) {
        const index = players.value.findIndex(p => p.id === message.data.player.id)
        if (index !== -1) {
          players.value[index] = message.data.player
        }
      }
      break
    case 'chatMessage':
      console.log('Chat message:', message)
      // 可以添加聊天消息处理逻辑，比如弹出提示或显示聊天框
      break
    default:
      console.log('Unknown message type:', message)
  }
}

const initCanvas = () => {
  if (gameCanvas.value) {
    canvasContext = gameCanvas.value.getContext('2d')
    gameCanvas.value.width = 800
    gameCanvas.value.height = 600
    
    // 绘制初始游戏画面
    draw()
  }
}

const initControls = () => {
  // 初始化游戏控制
}

const handleKeyDown = (e) => {
  if (keys.hasOwnProperty(e.key)) {
    keys[e.key] = true
    e.preventDefault()
  }
}

const handleKeyUp = (e) => {
  if (keys.hasOwnProperty(e.key)) {
    keys[e.key] = false
    e.preventDefault()
  }
}

const gameLoop = () => {
  if (!props.gameState.paused && !gameOver.value && !gameWon.value) {
    if (gameStarted.value) {
      update()
      draw()
    }
  } else {
    draw()
  }
  
  // 总是请求下一个动画帧，确保游戏循环持续运行
  animationFrameId = requestAnimationFrame(gameLoop)
}

const update = () => {
    // 游戏逻辑更新
    // 键盘控制已经在handleKeyDown和handleKeyUp中处理
    // 触摸控制已经在moveLeft、moveRight、stopMove和jump中处理
    
    // 键盘控制
    if (keys.ArrowLeft) {
      marioXSpeed.value = -5
      marioStatus.value = marioStatus.value.includes('jump') ? 'jump--left' : 'move--left'
    } else if (keys.ArrowRight) {
      marioXSpeed.value = 5
      marioStatus.value = marioStatus.value.includes('jump') ? 'jump--right' : 'move--right'
    } else {
      marioXSpeed.value = 0
      marioStatus.value = marioStatus.value.includes('jump') ? marioStatus.value : (marioStatus.value.includes('left') ? 'stop--left' : 'stop--right')
    }
    
    // 跳跃逻辑
    if (keys.ArrowUp && marioUpTime.value === 0) {
      // 检查是否在地面或障碍物上，允许跳跃
      let canJump = false
      
      // 检查是否在地面上
      if (marioY.value + 40 >= 380) {
        canJump = true
      }
      
      // 检查是否在障碍物上
      obstacles.value.forEach(obstacle => {
        const marioBottom = marioY.value + 40
        if (marioBottom >= obstacle.y && marioBottom <= obstacle.y + 10) {
          canJump = true
        }
      })
      
      if (canJump) {
        // 调整跳跃高度，只能顶到第一关石头的高度
        marioYSpeed.value = -10
        marioUpTime.value = 8
        marioStatus.value = marioStatus.value.includes('left') ? 'jump--left' : 'jump--right'
      }
    }
    
    // 更新马里奥位置
    marioX.value += marioXSpeed.value
    
    // 跳跃计时
    if (marioUpTime.value > 0) {
      marioY.value += marioYSpeed.value
      marioUpTime.value--
    } else {
      // 下落
      marioY.value += 5
    }
    
    // 边界检测
    if (marioX.value < 0) marioX.value = 0
    if (marioX.value > 775) {
      // 关卡切换逻辑
      if (currentLevel.value < totalLevels) {
        currentLevel.value++
        marioX.value = 10
        marioY.value = 355
        
        // 初始化新关卡地图
        if (currentLevel.value === 2) {
          initLevel2Map()
          // 初始化第二关敌人，根据Java代码设置每个敌人的移动范围，调整露出高度与第一关一致
          enemies.value = [
            { id: 1, x: 75, y: 418, width: 40, height: 40, direction: -1, speed: 0.5, alive: true, type: 2, frame: 0, minY: 328, maxY: 418 }, // 第一个食人花，minY=328，与第一关一致，露出高度适中
            { id: 2, x: 635, y: 388, width: 40, height: 40, direction: -1, speed: 0.5, alive: true, type: 2, frame: 0, minY: 298, maxY: 388 }, // 第二个食人花，minY=298，露出高度与第一关一致
            { id: 3, x: 200, y: 385, width: 40, height: 40, direction: 1, speed: 0.5, alive: true, type: 1, frame: 0 }, // 第一个蘑菇
            { id: 4, x: 500, y: 385, width: 40, height: 40, direction: 1, speed: 0.5, alive: true, type: 1, frame: 0 }  // 第二个蘑菇
          ]
        } else if (currentLevel.value === 3) {
          initLevel3Map()
          // 初始化第三关敌人
          enemies.value = [
            { id: 1, x: 150, y: 385, width: 40, height: 40, direction: 1, speed: 0.5, alive: true, type: 1, frame: 0 } // 蘑菇敌人
          ]
        }
      } else {
        // 所有关卡完成，游戏胜利
        gameWon.value = true
        marioIsOK.value = true
      }
    }
    
    // 障碍物碰撞检测 - 修复马里奥跳到石头上不能站在石头上的问题
    obstacles.value.forEach((obstacle) => {
      // 计算马里奥的碰撞盒
      const marioBottom = marioY.value + 40
      const marioTop = marioY.value
      const marioLeft = marioX.value
      const marioRight = marioX.value + 30
      
      const obstacleBottom = obstacle.y + obstacle.height
      const obstacleTop = obstacle.y
      const obstacleLeft = obstacle.x
      const obstacleRight = obstacle.x + obstacle.width
      
      // 检测马里奥是否与障碍物发生碰撞
      const isColliding = marioRight > obstacleLeft && 
                         marioLeft < obstacleRight && 
                         marioBottom > obstacleTop && 
                         marioTop < obstacleBottom
      
      if (isColliding) {
        // 检测马里奥是否在障碍物上方
        if (marioBottom <= obstacleBottom && marioBottom >= obstacleTop && marioY.value < obstacle.y) {
          // 马里奥站在障碍物上
          marioY.value = obstacleTop - 40
          marioUpTime.value = 0
          marioYSpeed.value = 0
          marioStatus.value = marioStatus.value.includes('jump') ? (marioStatus.value.includes('left') ? 'stop--left' : 'stop--right') : marioStatus.value
        }
        // 检测马里奥是否从下方碰到障碍物顶部
        else if (marioTop <= obstacleBottom && marioTop >= obstacleBottom - 10) {
          // 马里奥碰到障碍物顶部
          marioY.value = obstacleBottom
          marioUpTime.value = 0
          marioYSpeed.value = 0 // 停止上升
        }
        // 检测马里奥是否从右侧碰到障碍物左侧
        else if (marioRight >= obstacleLeft && marioRight <= obstacleLeft + 10) {
          // 马里奥碰到障碍物左侧
          marioX.value = obstacleLeft - 30
          marioXSpeed.value = 0
        }
        // 检测马里奥是否从左侧碰到障碍物右侧
        else if (marioLeft <= obstacleRight && marioLeft >= obstacleRight - 10) {
          // 马里奥碰到障碍物右侧
          marioX.value = obstacleRight
          marioXSpeed.value = 0
        }
      }
      
      // 判断是否跳起来顶到方块
      if (marioYSpeed.value < 0 && // 确保马里奥正在上升
          marioTop <= obstacleBottom + 10 && marioTop >= obstacleBottom - 10 &&
          marioRight > obstacleLeft && marioLeft < obstacleRight) {
        if (obstacle.type === 0) {
          // 破坏黄色石头，使其消失
          const obstacleIndex = obstacles.value.findIndex(obs => obs.id === obstacle.id)
          if (obstacleIndex !== -1) {
            obstacles.value.splice(obstacleIndex, 1) // 从数组中移除，使其消失
            marioScore.value += 100
          }
        }
        marioUpTime.value = 0
        marioYSpeed.value = 0 // 停止上升
      }
    })
    
    // 地面碰撞检测
    if (marioY.value > 380) {
      marioY.value = 380
      marioUpTime.value = 0
      marioYSpeed.value = 0
      marioStatus.value = marioStatus.value.includes('left') ? 'stop--left' : 'stop--right'
    }
    
    // 同步马里奥位置到玩家列表
    if (Array.isArray(players.value)) {
      // 单人模式下确保自己的角色存在
      // 单人游戏模式
        // 过滤掉其他玩家
        players.value = players.value.filter(player => player.id === props.playerInfo?.id)
        
        // 如果玩家列表为空，添加自己的角色
        if (players.value.length === 0 && props.playerInfo) {
          players.value.push({
            id: props.playerInfo.id,
            name: props.playerInfo.username,
            role: 'mario',
            x: marioX.value,
            y: marioY.value,
            status: marioStatus.value
          })
        }
      }
      
      // 更新自己的位置
      players.value.forEach((player, index) => {
        if (player.id === props.playerInfo?.id) {
          players.value[index] = {
            ...player,
            x: marioX.value,
            y: marioY.value,
            status: marioStatus.value
          }
        }
      })
    
    // 更新小怪位置
    enemies.value.forEach(enemy => {
      if (enemy.alive) {
        if (enemy.type === 1) { // 蘑菇敌人
          enemy.x += enemy.direction * enemy.speed
          
          // 小怪碰到边界后改变方向 - 向左移动到界面顶端(50)再返回
          if (enemy.x < 50 || enemy.x > 650) {
            enemy.direction *= -1
          }
          
          // 小怪动画
          enemy.frame = Math.floor(Date.now() / 200) % 2
        } else if (enemy.type === 2) { // 食人花敌人
          // 食人花上下移动 - 像生长在绿色水管内一样
          enemy.y += enemy.direction * enemy.speed
          
          // 使用每个敌人自身的minY和maxY属性作为移动范围
          // 根据Java代码提供的移动范围：
          // 第一关食人花：328-428
          // 第二关第一个食人花：328-418
          // 第二关第二个食人花：298-388
          if (enemy.minY && enemy.maxY) {
            if (enemy.y < enemy.minY || enemy.y > enemy.maxY) {
              enemy.direction *= -1
            }
          } else {
            // 兼容没有minY和maxY的敌人
            if (enemy.y < 310 || enemy.y > 420) {
              enemy.direction *= -1
            }
          }
          
          // 食人花动画
          enemy.frame = Math.floor(Date.now() / 200) % 2
        }
      }
    })
    
    // 碰撞检测
    if (Array.isArray(players.value) && players.value.length > 0) {
      players.value.forEach(player => {
        const playerX = player.x || 100
        const playerY = player.y || 450
        
        enemies.value.forEach(enemy => {
          if (enemy.alive) {
            // 检测马里奥是否跳到小怪头上
            if (playerY + 40 >= enemy.y && playerY + 40 <= enemy.y + 10 && 
                playerX + 15 >= enemy.x && playerX + 15 <= enemy.x + enemy.width) {
              enemy.alive = false
              marioScore.value += 100
            } 
            // 检测马里奥是否碰到小怪身体
            else if (playerX < enemy.x + enemy.width && playerX + 30 > enemy.x && 
                     playerY < enemy.y + enemy.height && playerY + 40 > enemy.y && !gameOver.value) {
              // 马里奥死亡，回到初始位置
              sendMessage({ type: 'playerRespawn' })
              marioIsDeath.value = true
              gameOver.value = true
            }
          }
        })
      })
    }
    
    // 调试信息：显示当前关卡和马里奥位置
    console.log('当前关卡:', currentLevel.value, '马里奥位置:', marioX.value, marioY.value, '旗子状态:', flagPulled.value, '下降状态:', isDescending.value)
    
    // 第三关特定逻辑：旗子交互和自动走到城堡
    if (currentLevel.value === 3) {
      // 1. 简化的旗子交互逻辑，确保能触发
      if (!flagPulled.value) {
        // 直接检测马里奥是否接近旗子位置
        const flagObstacle = obstacles.value.find(obs => obs.type === 8)
        if (flagObstacle) {
          // 计算马里奥与旗子的距离
          const distanceX = Math.abs((marioX.value + 15) - (flagObstacle.x + flagObstacle.width / 2))
          const distanceY = Math.abs((marioY.value + 20) - (flagObstacle.y + flagObstacle.height / 2))
          
          console.log('马里奥与旗子的距离:', distanceX, distanceY)
          
          // 当距离小于阈值时拉下拉旗
          if (distanceX < 50 && distanceY < 100) {
            flagPulled.value = true
            isDescending.value = true
            marioScore.value += 1000
            console.log('旗子被拉下！开始下降动画')
          }
        }
      }
      
      // 2. 拉下拉旗后，与旗子一起缓慢下降到地面砖头
      else if (flagPulled.value && isDescending.value) {
        // 地面砖头位置（y: 420），计算旗子应该下降到的位置
        const flagTargetY = 420 - 250 // 地面砖头y值 - 旗子初始y值 = 旗子需要下降的偏移量
        const marioTargetY = 380 - 40 // 马里奥脚的位置
        
        // 旗子和马里奥一起下降
        flagY.value += 2 // 旗子下降速度
        marioY.value += 2 // 马里奥下降速度
        marioStatus.value = 'stop--right' // 下降时保持站立状态
        
        console.log('下降中：旗子Y偏移:', flagY.value, '目标偏移:', flagTargetY, '马里奥Y位置:', marioY.value)
        
        // 检测是否到达地面砖头位置
        if (flagY.value >= flagTargetY || marioY.value >= marioTargetY) {
          // 调整到目标位置
          flagY.value = flagTargetY
          marioY.value = marioTargetY
          // 停止下降
          isDescending.value = false
          console.log('下降完成，到达地面砖头！')
        }
      }
      
      // 3. 下降到地面后，自动走到城堡
      else if (flagPulled.value && !isDescending.value && !isEnteringCastle.value && !castleEntered.value) {
        // 自动向右移动
        marioXSpeed.value = 2
        marioStatus.value = 'move--right'
        
        // 检测是否到达城堡门口
        if (marioX.value + 30 >= 550) {
          isEnteringCastle.value = true
          marioXSpeed.value = 0
          console.log('到达城堡门口！')
        }
      }
      
      // 4. 进入城堡动画
      else if (isEnteringCastle.value && !castleEntered.value) {
        // 向上移动进入城堡
        marioY.value -= 2
        marioStatus.value = 'jump--right'
        
        // 检测是否完全进入城堡
        if (marioY.value + 40 <= 330) {
          castleEntered.value = true
          // 游戏胜利
          gameWon.value = true
          marioIsOK.value = true
          console.log('进入城堡，游戏胜利！')
        }
      }
    }
    
    
}

const draw = () => {
  if (!canvasContext) return
  
  // 清除画布
  canvasContext.clearRect(0, 0, gameCanvas.value.width, gameCanvas.value.height)
  
  // 绘制游戏背景
  if (backgroundImage.value.complete && backgroundImage.value.naturalHeight > 0) {
    // 平铺背景图片
    const pattern = canvasContext.createPattern(backgroundImage.value, 'repeat-x')
    canvasContext.fillStyle = pattern
    canvasContext.fillRect(0, 0, gameCanvas.value.width, gameCanvas.value.height)
  } else {
    // 图片加载失败时使用默认背景色
    canvasContext.fillStyle = '#87CEEB'
    canvasContext.fillRect(0, 0, gameCanvas.value.width, gameCanvas.value.height)
  }
  
  // 绘制地面
  canvasContext.fillStyle = '#8B4513'
  canvasContext.fillRect(0, 500, gameCanvas.value.width, 100)
  
  // 绘制障碍物
  if (brickImage.value.complete && brickImage.value.naturalHeight > 0) {
    obstacles.value.forEach(obstacle => {
      switch (obstacle.type) {
        case 0: // 可破坏砖块
          canvasContext.drawImage(brickImage.value, obstacle.x, obstacle.y, obstacle.width, obstacle.height)
          break
        case 1: // 地板砖
          canvasContext.drawImage(brick2Image.value, obstacle.x, obstacle.y, obstacle.width, obstacle.height)
          break
        case 2: // 土壤
          if (obstacle.y === 480) {
            canvasContext.drawImage(soilBaseImage.value, obstacle.x, obstacle.y, obstacle.width, obstacle.height)
          } else {
            canvasContext.drawImage(soilUpImage.value, obstacle.x, obstacle.y, obstacle.width, obstacle.height)
          }
          break
        case 3: // 水管头部左
          canvasContext.drawImage(pipe1Image.value, obstacle.x, obstacle.y, obstacle.width, obstacle.height)
          break
        case 4: // 水管头部右
          canvasContext.drawImage(pipe2Image.value, obstacle.x, obstacle.y, obstacle.width, obstacle.height)
          break
        case 5: // 水管身体左
          canvasContext.drawImage(pipe3Image.value, obstacle.x, obstacle.y, obstacle.width, obstacle.height)
          break
        case 6: // 水管身体右
          canvasContext.drawImage(pipe4Image.value, obstacle.x, obstacle.y, obstacle.width, obstacle.height)
          break
        case 7: // 空砖块
          canvasContext.drawImage(brick2Image.value, obstacle.x, obstacle.y, obstacle.width, obstacle.height)
          break
        case 8: // 旗子
          // 使用动态Y偏移量绘制旗子，实现下降效果
          const finalFlagY = obstacle.y + flagY.value
          canvasContext.drawImage(flagImage.value, obstacle.x, finalFlagY, obstacle.width, obstacle.height)
          break
        case 9: // 城堡
          canvasContext.drawImage(towerImage.value, obstacle.x, obstacle.y, obstacle.width, obstacle.height)
          break
        case 10: // 旗杆
          // 绘制旗杆，使用深色线条
          canvasContext.fillStyle = '#333333'
          canvasContext.fillRect(obstacle.x, obstacle.y, obstacle.width, obstacle.height)
          break
      }
    })
  }
  
  // 绘制小怪
  if (fungus1Image.value.complete && fungus1Image.value.naturalHeight > 0) {
    enemies.value.forEach(enemy => {
      if (enemy.alive) {
        // 小怪动画
        let enemyImage
        if (enemy.type === 1) { // 蘑菇敌人
          enemyImage = enemy.frame === 0 ? fungus1Image.value : fungus2Image.value
          canvasContext.drawImage(enemyImage, enemy.x, enemy.y, enemy.width, enemy.height)
        } else if (enemy.type === 2) { // 食人花敌人
          enemyImage = enemy.frame === 0 ? flower1Image.value : flower2Image.value
          
          // 计算水管的位置和高度，根据实际水管高度调整
          let pipeTopY = 0
          let pipeX = 0
          
          if (currentLevel.value === 2) {
            // 第二关特殊处理，根据不同水管的实际高度调整
            if (enemy.x === 75) { // 第二关第一个食人花，对应第一个水管
              pipeTopY = 360 // 水管头部y值
              pipeX = 60 // 水管x值
            } else if (enemy.x === 635) { // 第二关第二个食人花，对应第二个水管
              pipeTopY = 330 // 水管头部y值，第二个水管更高
              pipeX = 620 // 水管x值
            }
          } else {
            // 其他关卡
            if (enemy.x === 635) { // 第一关食人花
              pipeTopY = 360 // 水管头部y值
              pipeX = 620 // 水管x值
            }
          }
          
          // 计算水管的总高度
          const pipeHeight = 240 // 水管总高度
          const pipeBottomY = pipeTopY + pipeHeight // 水管底部y值
          
          // 计算食人花相对于水管的位置
          if (enemy.y < pipeBottomY) {
            // 食人花在水管内或顶部附近，需要被水管遮盖
            
            // 计算可见部分：只有当食人花顶部高于水管顶部时才可见
            const flowerTopY = enemy.y
            if (flowerTopY < pipeTopY) {
              // 食人花顶部高于水管顶部，计算可见高度
              const visibleHeight = pipeTopY - flowerTopY
              
              // 绘制食人花，只显示水管外的部分
              canvasContext.drawImage(
                enemyImage, 
                0, 0, // 源图像起始位置
                enemy.width, visibleHeight, // 源图像高度为可见高度
                enemy.x, flowerTopY, // 目标位置
                enemy.width, visibleHeight // 目标高度为可见高度
              )
            }
            // 否则，食人花完全在水管内，不显示
          }
        }
      }
    })
  }
  
  // 绘制马里奥角色
  let marioImage = marioStandRight.value
  
  // 根据玩家状态选择合适的图片
  if (marioStatus.value === 'jump--right' || marioStatus.value === 'jump--left') {
    marioImage = marioStatus.value === 'jump--left' ? marioJumpLeft.value : marioJumpRight.value
  } else if (marioStatus.value === 'move--right' || marioStatus.value === 'move--left') {
    // 切换跑步动画帧
    const frameIndex = Math.floor(Date.now() / 150) % 2
    if (marioStatus.value === 'move--left') {
      marioImage = frameIndex === 0 ? marioRunLeft1.value : marioRunLeft2.value
    } else {
      marioImage = frameIndex === 0 ? marioRunRight1.value : marioRunRight2.value
    }
  } else {
    marioImage = marioStatus.value === 'stop--left' || marioStatus.value === 'move--left' ? marioStandLeft.value : marioStandRight.value
  }
  
  // 确保图片已加载完成
  if (marioImage.complete && marioImage.naturalHeight > 0) {
    canvasContext.drawImage(marioImage, marioX.value, marioY.value, 30, 40) // 调整大小为30x40，与原版一致
  } else {
    // 图片加载失败时使用默认矩形
    canvasContext.fillStyle = '#E52521'
    canvasContext.fillRect(marioX.value, marioY.value, 30, 40)
  }
  
  // 绘制玩家名称
  canvasContext.fillStyle = '#000'
  canvasContext.font = '12px Arial'
  canvasContext.fillText(props.playerInfo?.username || 'Mario', marioX.value, marioY.value - 10)
}

// 重新开始游戏
const restartGame = () => {
  gameOver.value = false
  gameWon.value = false
  marioIsDeath.value = false
  marioIsOK.value = false
  marioScore.value = 0
  
  // 重置游戏状态标志
  gameStarted.value = false
  flagPulled.value = false
  isDescending.value = false
  isEnteringCastle.value = false
  castleEntered.value = false
  flagY.value = 0
  
  // 重置关卡到第一关
  currentLevel.value = 1
  
  // 重置马里奥位置和速度
  marioX.value = 10
  marioY.value = 380 // 调整Y坐标，与原版一致
  marioXSpeed.value = 0
  marioYSpeed.value = 0
  marioUpTime.value = 0
  
  // 重置小怪，根据Java代码设置正确的移动范围
  enemies.value = [
    { id: 1, x: 580, y: 385, width: 40, height: 40, direction: 1, speed: 0.5, alive: true, type: 1, frame: 0 }, // 蘑菇敌人
    { id: 2, x: 635, y: 420, width: 40, height: 40, direction: -1, speed: 0.5, alive: true, type: 2, frame: 0, minY: 328, maxY: 428 }  // 食人花敌人，移动范围328-428
  ]
  
  // 重置障碍物
  initLevel1Map()
  
  // 清除之前的动画帧，避免多个游戏循环同时运行
  if (animationFrameId) {
    cancelAnimationFrame(animationFrameId)
    animationFrameId = null
  }
  
  // 绘制初始画面
  draw()
}

// 暴露方法给父组件
defineExpose({
  pauseGame: () => emit('pause'),
  restartGame
})
</script>

<style scoped>
.screen {
  position: relative;
  width: 100%;
  height: 100vh;
  overflow: hidden;
  background: linear-gradient(to bottom, #87CEEB 0%, #98FB98 100%);
}

.hud {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 10px 20px;
  background: rgba(0, 0, 0, 0.5);
  color: white;
  font-family: 'Arial', sans-serif;
  z-index: 100;
}

.hud-left, .hud-right {
  display: flex;
  flex-direction: column;
  gap: 5px;
}

.hud-center {
  text-align: center;
}

.score-display, .health-display {
  display: flex;
  align-items: center;
  gap: 5px;
}

.hearts {
  display: flex;
  gap: 5px;
}

.heart-lost {
  opacity: 0.3;
}

.game-container {
  position: relative;
  width: 100%;
  height: 100%;
  display: flex;
  justify-content: center;
  align-items: center;
}

canvas {
  border: 2px solid #333;
  border-radius: 5px;
  background: #87CEEB;
}

.game-over-screen, .game-won-screen {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.8);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 200;
}

.game-over-content, .game-won-content {
  background: white;
  padding: 40px;
  border-radius: 10px;
  text-align: center;
  box-shadow: 0 0 20px rgba(0, 0, 0, 0.5);
}

h1 {
  font-size: 48px;
  margin-bottom: 20px;
  color: #E52521;
}

.game-won-content h1 {
  color: #4CAF50;
}

p {
  font-size: 24px;
  margin-bottom: 20px;
  color: #333;
}

button {
  padding: 15px 30px;
  font-size: 20px;
  background: #E52521;
  color: white;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  transition: background 0.3s;
}

button:hover {
  background: #C02020;
}

.game-won-content button {
  background: #4CAF50;
}

.game-won-content button:hover {
  background: #45A049;
}

/* 开始游戏屏幕样式 */
.start-game-screen {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  display: flex;
  justify-content: center;
  align-items: center;
  background: url('/images/start-bg.png') no-repeat center center;
  background-size: cover;
  z-index: 200;
}

.start-game-content {
  text-align: center;
  background: white;
  padding: 40px;
  border-radius: 10px;
  box-shadow: 0 0 20px rgba(0, 0, 0, 0.5);
}

.start-game-content h1 {
  font-size: 48px;
  margin-bottom: 10px;
  color: #E52521;
  font-family: 'Arial', sans-serif;
}

.start-game-content p {
  font-size: 24px;
  margin-bottom: 30px;
  color: #333;
  font-family: 'Arial', sans-serif;
}

.start-button {
  padding: 15px 40px;
  font-size: 24px;
  background: #E52521;
  color: white;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  transition: background 0.3s;
  font-family: 'Arial', sans-serif;
  font-weight: bold;
}

.start-button:hover {
  background: #C02020;
  transform: scale(1.05);
}
</style>