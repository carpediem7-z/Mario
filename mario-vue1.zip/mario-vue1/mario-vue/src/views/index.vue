<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>马里奥游戏</title>
    
    <!-- 样式表 -->
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/responsive.css">
    <link rel="stylesheet" href="css/ui.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <!-- 加载屏幕 -->
    <div id="loading-screen" class="screen">
        <div class="loading-container">
            <div class="loading-logo">
                <div class="logo-placeholder">M</div>
                <h1>马里奥游戏</h1>
            </div>
            <div class="loading-progress">
                <div class="progress-bar">
                    <div class="progress-fill" id="progress-fill"></div>
                </div>
                <div class="loading-text" id="loading-text">正在连接服务器...</div>
            </div>
        </div>
    </div>

    <!-- 登录/注册界面 -->
    <div id="auth-screen" class="screen hidden">
        <div class="auth-container">
            <div class="auth-logo">
                <div class="logo-placeholder">M</div>
                <h2>欢迎来到马里奥游戏</h2>
            </div>
            
            <div class="auth-form">
                <div class="form-group">
                    <input type="text" id="username" placeholder="请输入玩家名" maxlength="12" value="玩家">
                    <i class="fas fa-user"></i>
                </div>
                <div class="auth-buttons">
                    <button id="btn-login" class="btn btn-primary">
                        <i class="fas fa-play"></i> 开始游戏
                    </button>
                    <button id="btn-guest" class="btn btn-secondary">
                        <i class="fas fa-user-clock"></i> 快速开始
                    </button>
                </div>
                <div class="server-status">
                    <div id="server-status-indicator" class="status-indicator offline"></div>
                    <span id="server-status-text">正在检测服务器...</span>
                </div>
            </div>
        </div>
    </div>

    <!-- 主菜单界面 -->
    <div id="menu-screen" class="screen hidden">
        <div class="menu-header">
            <h1><i class="fas fa-gamepad"></i> 马里奥游戏大厅</h1>
            <!-- 在主菜单的player-info区域添加 -->
            <div class="player-info" id="player-info">
                <span class="player-name">游客</span>
                <img src="assets/ui/avatar.svg" class="player-avatar" alt="头像">
                <button id="btn-logout" class="btn-icon logout-btn" title="退出登录">
                    <i class="fas fa-sign-out-alt"></i>
                </button>
        </div>
    </div>
        
        <div class="menu-content">
            
            <div class="menu-section">
                <h2><i class="fas fa-info-circle"></i> 游戏说明</h2>
                <div class="game-instructions">
                    <p><i class="fas fa-arrow-left"></i> <i class="fas fa-arrow-right"></i> 左右移动</p>
                    <p><i class="fas fa-arrow-up"></i> 空格键跳跃</p>
                </div>
            </div>
            
            <div class="menu-section">
                <h2><i class="fas fa-cog"></i> 设置</h2>
                <div class="settings">
                    <div class="setting-item">
                        <label>音量控制</label>
                        <input type="range" id="volume-slider" min="0" max="100" value="70">
                    </div>
                    <div class="setting-item">
                        <label>控制方式</label>
                        <select id="control-mode">
                            <option value="keyboard">键盘控制</option>
                            <option value="touch">触摸控制</option>
                            <option value="both">键盘+触摸</option>
                        </select>
                    </div>
                    <div class="setting-item">
                        <label>角色选择</label>
                        <select id="player-role">
                            <option value="mario">马里奥 (红色)</option>
                            <option value="luigi">路易吉 (绿色)</option>
                        </select>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- 游戏屏幕 -->
<div id="game-screen" class="screen hidden">
    <!-- HUD（游戏界面头部信息） -->
    <div class="hud">
        <div class="hud-left">
            <div class="score-display">
                <i class="fas fa-star"></i>
                <span>分数: <span id="score">0</span></span>
            </div>
        </div>
        <div class="hud-center">
                <div class="game-title">马里奥游戏</div>
            </div>
        <div class="hud-right">
            <div class="health-display">
                <div class="hearts">
                    <i class="fas fa-heart"></i>
                    <i class="fas fa-heart"></i>
                    <i class="fas fa-heart"></i>
                </div>
            </div>
        </div>
    </div>
    
    <!-- 游戏画布容器 -->
    <div class="game-container">
        <canvas id="game-canvas"></canvas>
    </div>
    
    <!-- 触摸控制（移动设备） -->
    <div class="touch-controls">
        <div class="touch-buttons">
            <div class="touch-button" id="btn-left">
                <i class="fas fa-arrow-left"></i>
            </div>
            <div class="touch-button" id="btn-right">
                <i class="fas fa-arrow-right"></i>
            </div>
            <div class="touch-button" id="btn-jump">
                <i class="fas fa-arrow-up"></i>
            </div>
        </div>
    </div>
</div>

    <!-- 暂停菜单 -->
    <div id="pause-screen" class="modal hidden">
        <div class="modal-content">
            <h2><i class="fas fa-pause"></i> 游戏暂停</h2>
            <div class="modal-buttons">
                <button id="btn-resume" class="btn btn-primary">
                    <i class="fas fa-play"></i> 继续游戏
                </button>
                <button id="btn-back-menu" class="btn btn-warning">
                    <i class="fas fa-home"></i> 返回大厅
                </button>
            </div>
        </div>
    </div>

    <!-- 加载JS文件 - 按正确顺序 -->
    <!-- 正确的顺序 -->
    <script src="js/api.js"></script>
    <script src="js/websocket.js"></script>
    <script src="js/controls.js"></script>
    <script src="js/ui.js"></script>
    <script src="js/game.js"></script>
    <script src="js/main.js"></script>

</body>
</html>