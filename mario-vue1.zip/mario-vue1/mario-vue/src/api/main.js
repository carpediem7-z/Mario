/**
 * 多人游戏主控制器
 */
class MarioGame {
    constructor() {
        console.log('多人马里奥游戏初始化...');
        this.currentScreen = 'loading';
        this.player = null;
        this.game = null;
        this.room = null;
        this.websocket = null;
        this.isMobile = false;
        this.isTablet = false;
        this.isTouchDevice = false;
        this.isCreatingRoom = false;  // 新增：创建房间状态
        this.originalPlayerId = null; // 保存原始玩家ID
        
        // 延迟初始化，确保所有依赖都加载完成
        setTimeout(() => {
            try {
                this.init();
            } catch (error) {
                console.error('初始化失败:', error);
                this.showFatalError('初始化失败: ' + error.message);
            }
        }, 100);
    }

    // 显示致命错误
    showFatalError(message) {
        const errorDiv = document.createElement('div');
        errorDiv.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0,0,0,0.9);
            color: white;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            z-index: 99999;
            padding: 20px;
            text-align: center;
        `;
        errorDiv.innerHTML = `
            <h1 style="color: #ff6b6b; margin-bottom: 20px;">游戏启动失败</h1>
            <p style="margin-bottom: 20px;">${message}</p>
            <button onclick="location.reload()" style="padding: 10px 20px; background: #feca57; border: none; border-radius: 5px; cursor: pointer;">
                重新加载页面
            </button>
        `;
        document.body.appendChild(errorDiv);
    }

    detectDevice() {
        try {
            this.isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
            this.isTablet = window.innerWidth <= 1024 && window.innerWidth > 480;
            this.isTouchDevice = 'ontouchstart' in window || navigator.maxTouchPoints > 0;
            
            console.log(`设备检测: ${this.isMobile ? '移动设备' : '桌面设备'}, 触摸设备: ${this.isTouchDevice}`);
        } catch (error) {
            console.warn('设备检测失败:', error);
            this.isMobile = false;
            this.isTablet = false;
            this.isTouchDevice = false;
        }
    }

    async checkConnection() {
        console.log('检查服务器连接...');
        
        try {
            // 确保api对象存在
            if (!window.api) {
                console.error('API对象未定义！');
                return { connected: false, message: 'API未初始化' };
            }
            
            if (!window.api.testConnection) {
                console.error('testConnection方法不存在！');
                return { connected: false, message: 'API方法不存在' };
            }
            
            const status = await window.api.testConnection();
            console.log('服务器连接状态:', status);
            
            return status.connected;
        } catch (error) {
            console.error('连接检查失败:', error);
            return { connected: false, error: error.message };
        }
    }

    async init() {
        console.log('马里奥游戏初始化...');
        
        try {
            // 检测设备
            this.detectDevice();
            
            // 检查后端连接
            const connectionStatus = await this.checkConnection();
            console.log('连接状态:', connectionStatus);
            
            // 初始化UI事件
            this.initUIEvents();
            
            // 初始化键盘控制 - 关键：添加这一行！
            this.initKeyboardControls();
            
            // 检查本地存储
            this.checkLocalStorage();
            
            // 总是显示登录界面
            this.showAuthScreen();
            
            console.log('多人马里奥游戏已加载完成！');
            
        } catch (error) {
            console.error('初始化过程中出错:', error);
            this.showNotification('初始化失败，请刷新页面重试', 'error');
        }
    }

    initUIEvents() {
        console.log('开始绑定UI事件...');
        
        try {
            // 登录按钮
            const loginBtn = document.getElementById('btn-login');
            if (loginBtn) {
                loginBtn.addEventListener('click', (e) => {
                    e.preventDefault();
                    this.handleLogin();
                });
            }
            
            // 快速开始按钮（原来是游客登录）
            const guestBtn = document.getElementById('btn-guest');
            if (guestBtn) {
                guestBtn.addEventListener('click', (e) => {
                    e.preventDefault();
                    this.handleGuestLogin();
                });
            }
            
            // 创建房间按钮
            const createRoomBtn = document.getElementById('btn-create-room');
            if (createRoomBtn) {
                createRoomBtn.addEventListener('click', (e) => {
                    e.preventDefault();
                    this.createNewRoom();
                });
            }
            
            // 刷新房间按钮
            const refreshBtn = document.getElementById('btn-refresh-rooms');
            if (refreshBtn) {
                refreshBtn.addEventListener('click', (e) => {
                    e.preventDefault();
                    this.loadRooms();
                });
            }
            
            // 创建房间模态框的确认和取消按钮
            const createConfirmBtn = document.getElementById('btn-create-room-confirm');
            if (createConfirmBtn) {
                createConfirmBtn.addEventListener('click', (e) => {
                    e.preventDefault();
                    this.confirmCreateRoom();
                });
            }
            
            const createCancelBtn = document.getElementById('btn-create-room-cancel');
            if (createCancelBtn) {
                createCancelBtn.addEventListener('click', (e) => {
                    e.preventDefault();
                    this.cancelCreateRoom();
                });
            }
            
            // 退出登录按钮
            const logoutBtn = document.getElementById('btn-logout');
            if (logoutBtn) {
                logoutBtn.addEventListener('click', (e) => {
                    e.preventDefault();
                    this.handleLogout();
                });
            }
            
            // 暂停菜单按钮
            const resumeBtn = document.getElementById('btn-resume');
            if (resumeBtn) {
                resumeBtn.addEventListener('click', (e) => {
                    e.preventDefault();
                    this.resumeGame();
                });
            }
            
            const changeRoomBtn = document.getElementById('btn-change-room');
            if (changeRoomBtn) {
                changeRoomBtn.addEventListener('click', (e) => {
                    e.preventDefault();
                    this.changeRoom();
                });
            }
            
            const backMenuBtn = document.getElementById('btn-back-menu');
            if (backMenuBtn) {
                backMenuBtn.addEventListener('click', (e) => {
                    e.preventDefault();
                    this.backToMenu();
                });
            }
            
            console.log('UI事件绑定完成');
            
        } catch (error) {
            console.error('绑定UI事件失败:', error);
        }
    }
    
    // ============================
    // 键盘控制方法（改进版）
    // ============================
    
    initKeyboardControls() {
        console.log('初始化键盘控制...');
        
        // 使游戏画布可以获得焦点
        this.setupCanvasFocus();
        
        // 全局键盘事件监听（使用window确保捕获所有事件）
        window.addEventListener('keydown', this.handleKeyDown.bind(this));
        window.addEventListener('keyup', this.handleKeyUp.bind(this));
        
        console.log('键盘控制初始化完成');
    }
    
    setupCanvasFocus() {
        const canvas = document.getElementById('game-canvas');
        if (!canvas) {
            console.warn('游戏画布不存在，无法设置焦点');
            return;
        }
        
        // 使画布可聚焦
        canvas.tabIndex = 0;
        canvas.style.outline = 'none';
        
        // 点击画布时自动获得焦点
        canvas.addEventListener('click', () => {
            canvas.focus();
            console.log('画布获得焦点');
        });
        
        // 游戏屏幕显示时自动获得焦点
        setTimeout(() => {
            if (this.currentScreen === 'game') {
                canvas.focus();
                console.log('游戏开始，画布自动获得焦点');
            }
        }, 1000);
    }
    
    // 在 main.js 的键盘控制部分修改

handleKeyDown(e) {
    // 调试信息
    console.log(`按键按下: ${e.key}, 当前屏幕: ${this.currentScreen}`);
    
    // ESC键处理
    if (e.key === 'Escape') {
        if (this.isCreatingRoom) {
            this.cancelCreateRoom();
            e.preventDefault();
            return;
        }
        
        if (this.currentScreen === 'game') {
            this.togglePause();
            e.preventDefault();
            return;
        }
    }
    
    // 只在游戏屏幕中处理游戏控制
    if (this.currentScreen !== 'game') return;
    
    // 阻止默认行为（如页面滚动）
    if (['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown', ' ', 'w', 'W', 'a', 'A', 'd', 'D'].includes(e.key)) {
        e.preventDefault();
    }
    
    // 处理游戏控制 - 关键：使用当前玩家的ID
    if (this.game && this.player) {
        // 总是使用最新的玩家ID
        const playerId = this.player.id;
        console.log(`控制玩家: ${playerId}, 名称: ${this.player.name}`);
        
        switch(e.key.toLowerCase()) {
            case 'arrowleft':
            case 'a':
                console.log('向左移动');
                this.game.movePlayer(playerId, 'LEFT');
                // 发送到服务器
                if (window.gameWebSocket && window.gameWebSocket.sendPlayerMove) {
                    window.gameWebSocket.sendPlayerMove('LEFT');
                }
                break;
            case 'arrowright':
            case 'd':
                console.log('向右移动');
                this.game.movePlayer(playerId, 'RIGHT');
                // 发送到服务器
                if (window.gameWebSocket && window.gameWebSocket.sendPlayerMove) {
                    window.gameWebSocket.sendPlayerMove('RIGHT');
                }
                break;
            case 'arrowup':
            case ' ':
            case 'w':
                console.log('跳跃');
                this.game.jumpPlayer(playerId);
                // 发送到服务器
                if (window.gameWebSocket && window.gameWebSocket.sendPlayerJump) {
                    window.gameWebSocket.sendPlayerJump();
                }
                break;
        }
    }
}

handleKeyUp(e) {
    if (this.currentScreen !== 'game') return;
    
    if (this.game && this.player) {
        const playerId = this.player.id;
        
        if (e.key === 'ArrowLeft' || e.key.toLowerCase() === 'a' ||
            e.key === 'ArrowRight' || e.key.toLowerCase() === 'd') {
            console.log('停止移动');
            this.game.movePlayer(playerId, 'STOP');
            // 发送到服务器
            if (window.gameWebSocket && window.gameWebSocket.sendPlayerMove) {
                window.gameWebSocket.sendPlayerMove('STOP');
            }
        }
    }
}

    async handleLogin() {
        try {
            const usernameInput = document.getElementById('username');
            if (!usernameInput) {
                this.showNotification('找不到用户名输入框', 'error');
                return;
            }
            
            const username = usernameInput.value.trim();
            if (!username) {
                this.showNotification('请输入玩家名', 'warning');
                return;
            }
            
            this.player = {
                id: `player_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
                name: username,
                role: 'mario',
                score: 0,
                sessionId: `session_${Date.now()}`
            };
            
            // 保存原始玩家ID
            this.originalPlayerId = this.player.id;
            
            // 保存到本地存储
            localStorage.setItem('mario_player', JSON.stringify(this.player));
            
            this.showNotification('登录成功！', 'success');
            this.showMenuScreen();
            
        } catch (error) {
            console.error('登录失败:', error);
            this.showNotification('登录失败: ' + error.message, 'error');
        }
    }

    handleGuestLogin() {
        try {
            const guestName = `游客_${Math.floor(Math.random() * 10000)}`;
            
            this.player = {
                id: `guest_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
                name: guestName,
                role: 'mario',
                score: 0,
                sessionId: `guest_${Date.now()}`
            };
            
            // 保存原始玩家ID
            this.originalPlayerId = this.player.id;
            
            // 保存到本地存储
            localStorage.setItem('mario_player', JSON.stringify(this.player));
            
            this.showNotification(`欢迎，${guestName}！`, 'success');
            this.showMenuScreen();
            
        } catch (error) {
            console.error('游客登录失败:', error);
            this.showNotification('游客登录失败', 'error');
        }
    }

    handleLogout() {
        try {
            localStorage.removeItem('mario_player');
            this.player = null;
            this.originalPlayerId = null;
            this.showNotification('已退出登录', 'info');
            this.showAuthScreen();
        } catch (error) {
            console.error('退出登录失败:', error);
        }
    }

    handleRegister() {
        this.showNotification('注册功能开发中，请使用游客登录', 'info');
    }

    // 屏幕切换方法
    showScreen(screenName) {
        console.log(`切换屏幕: ${this.currentScreen} -> ${screenName}`);
        
        try {
            // 隐藏所有屏幕
            const screens = document.querySelectorAll('.screen');
            screens.forEach(el => {
                el.classList.add('hidden');
                el.classList.remove('active');
            });
            
            // 显示目标屏幕
            const targetScreen = document.getElementById(`${screenName}-screen`);
            if (targetScreen) {
                targetScreen.classList.remove('hidden');
                targetScreen.classList.add('active');
                this.currentScreen = screenName;
                console.log(`切换到屏幕: ${screenName}`);
                
                // 特殊处理游戏屏幕
                if (screenName === 'game') {
                    // 延迟调整画布大小，确保DOM已更新
                    setTimeout(() => {
                        this.resizeGameCanvas();
                    }, 100);
                    
                    // 游戏开始时自动给画布焦点
                    setTimeout(() => {
                        const canvas = document.getElementById('game-canvas');
                        if (canvas) {
                            canvas.focus();
                            console.log('游戏屏幕显示，画布获得焦点');
                        }
                    }, 200);
                }
            }
        } catch (error) {
            console.error('切换屏幕失败:', error);
        }
    }

    resizeGameCanvas() {
        console.log('调整游戏画布大小...');
        
        const canvas = document.getElementById('game-canvas');
        if (!canvas) {
            console.error('游戏画布不存在');
            return;
        }
        
        const gameContainer = document.querySelector('.game-container');
        if (!gameContainer) {
            console.error('游戏容器不存在');
            return;
        }
        
        // 获取容器尺寸（减去HUD高度）
        const hudHeight = document.querySelector('.hud')?.offsetHeight || 50;
        const containerWidth = gameContainer.clientWidth;
        const containerHeight = window.innerHeight - hudHeight;
        
        // 游戏原始宽高比 (800x600 = 4:3)
        const gameAspectRatio = 800 / 600;
        const containerAspectRatio = containerWidth / containerHeight;
        
        let canvasWidth, canvasHeight;
        
        if (containerAspectRatio > gameAspectRatio) {
            // 容器更宽，高度限制
            canvasHeight = containerHeight;
            canvasWidth = canvasHeight * gameAspectRatio;
        } else {
            // 容器更高，宽度限制
            canvasWidth = containerWidth;
            canvasHeight = canvasWidth / gameAspectRatio;
        }
        
        // 确保最小尺寸
        canvasWidth = Math.max(canvasWidth, 400);
        canvasHeight = Math.max(canvasHeight, 300);
        
        // 设置画布CSS尺寸
        canvas.style.width = `${canvasWidth}px`;
        canvas.style.height = `${canvasHeight}px`;
        
        // 设置画布像素尺寸（重要！）
        canvas.width = canvasWidth;
        canvas.height = canvasHeight;
        
        console.log(`画布尺寸: ${canvasWidth}x${canvasHeight}`);
        console.log(`容器尺寸: ${containerWidth}x${containerHeight}`);
        
        // 如果游戏引擎已初始化，通知它调整大小
        if (this.game && typeof this.game.resizeCanvas === 'function') {
            setTimeout(() => {
                this.game.resizeCanvas();
            }, 50);
        }
    }

    showAuthScreen() {
        this.showScreen('auth');
    }

    showMenuScreen() {
        this.showScreen('menu');
        
        // 更新玩家信息
        if (this.player) {
            const playerNameElements = document.querySelectorAll('.player-name');
            playerNameElements.forEach(element => {
                element.textContent = this.player.name;
            });
        }
        
        // 加载房间列表
        this.loadRooms();
    }

    // 游戏屏幕显示方法
    showGameScreen(roomData) {
        console.log('显示游戏屏幕，房间数据:', roomData);
        
        try {
            // 切换到游戏屏幕
            this.showScreen('game');
            
            // 保存房间信息
            if (roomData) {
                this.room = roomData;
                if (this.player) {
                    this.player.roomId = roomData.roomId || roomData.id;
                }
            }
            
            // 延迟初始化游戏引擎，确保DOM已更新
            setTimeout(() => {
                this.initializeGameEngine();
            }, 200);
            
        } catch (error) {
            console.error('显示游戏屏幕时出错:', error);
            this.showNotification('游戏启动失败: ' + error.message, 'error');
        }
    }

    // ============================
    // 创建房间相关方法
    // ============================
    
    createNewRoom() {
        console.log('创建新房间...');
        
        if (!this.player) {
            this.showNotification('请先登录', 'warning');
            return;
        }
        
        // 显示创建房间模态框
        this.showCreateRoomModal();
    }
    
    showCreateRoomModal() {
        console.log('显示创建房间模态框');
        
        const modal = document.getElementById('create-room-modal');
        if (!modal) {
            console.error('创建房间模态框不存在');
            // 如果没有模态框，使用简单方式
            this.simpleCreateRoom();
            return;
        }
        
        // 显示模态框
        modal.classList.remove('hidden');
        modal.style.display = 'flex';
        
        // 设置默认房间名称
        const roomNameInput = document.getElementById('room-name-input');
        if (roomNameInput) {
            roomNameInput.value = `${this.player.name}的房间`;
            roomNameInput.focus();
            roomNameInput.select();
        }
        
        // 设置默认最大玩家数
        const maxPlayersSelect = document.getElementById('room-max-players');
        if (maxPlayersSelect) {
            maxPlayersSelect.value = '4';
        }
        
        // 存储当前模态框状态
        this.isCreatingRoom = true;
    }
    
    hideCreateRoomModal() {
        console.log('隐藏创建房间模态框');
        
        const modal = document.getElementById('create-room-modal');
        if (modal) {
            modal.classList.add('hidden');
            modal.style.display = 'none';
        }
        
        this.isCreatingRoom = false;
    }
    
    confirmCreateRoom() {
        console.log('确认创建房间');
        
        const roomNameInput = document.getElementById('room-name-input');
        const maxPlayersSelect = document.getElementById('room-max-players');
        
        if (!roomNameInput || !maxPlayersSelect) {
            this.showNotification('无法获取房间信息', 'error');
            return;
        }
        
        const roomName = roomNameInput.value.trim();
        const maxPlayers = parseInt(maxPlayersSelect.value) || 4;
        
        if (!roomName) {
            this.showNotification('请输入房间名称', 'warning');
            roomNameInput.focus();
            return;
        }
        
        if (roomName.length < 2 || roomName.length > 20) {
            this.showNotification('房间名称长度应在2-20个字符之间', 'warning');
            roomNameInput.focus();
            return;
        }
        
        if (maxPlayers < 2 || maxPlayers > 10) {
            this.showNotification('玩家数量应为2-10人', 'warning');
            return;
        }
        
        // 隐藏模态框
        this.hideCreateRoomModal();
        
        // 处理房间创建
        this.processRoomCreation(roomName, maxPlayers);
    }
    
    cancelCreateRoom() {
        console.log('取消创建房间');
        this.hideCreateRoomModal();
    }
    
    async processRoomCreation(roomName, maxPlayers) {
        this.showNotification('正在创建房间...', 'info');
        
        try {
            if (!window.api || !window.api.createRoom) {
                // 如果API不可用，模拟创建房间并加入
                this.showNotification('创建房间功能开发中，将为您创建模拟房间', 'info');
                
                // 模拟创建房间响应
                const roomData = {
                    roomId: `room_${Date.now()}`,
                    roomName: roomName,
                    maxPlayers: maxPlayers,
                    currentPlayers: 1,
                    createdBy: this.player.id
                };
                
                this.room = roomData;
                this.player.roomId = roomData.roomId;
                
                // 延迟显示，让用户看到通知
                setTimeout(() => {
                    this.showNotification(`房间 "${roomName}" 创建成功！`, 'success');
                    this.showGameScreen(roomData);
                }, 1000);
                
                return;
            }
            
            // 调用后端API创建房间
            const response = await window.api.createRoom({
                roomName: roomName,
                maxPlayers: maxPlayers,
                createdBy: this.player.id,
                playerName: this.player.name,
                playerRole: this.player.role || 'mario'
            });
            
            if (response.success) {
                const roomData = response.data;
                this.room = roomData;
                this.player.roomId = roomData.roomId;
                
                this.showNotification(`房间 "${roomData.roomName}" 创建成功！`, 'success');
                this.showGameScreen(roomData);
            } else {
                throw new Error(response.message || '创建房间失败');
            }
        } catch (error) {
            console.error('创建房间失败:', error);
            this.showNotification('创建房间失败: ' + error.message, 'error');
            
            // 询问是否加入默认房间
            if (confirm('创建房间失败，是否加入默认房间？')) {
                this.joinRoom('room-1');
            }
        }
    }
    
    // 简单的创建房间方法（备用，如果没有模态框）
    simpleCreateRoom() {
        const roomName = prompt('请输入房间名称:', `${this.player.name}的游戏房间`);
        if (!roomName) return;
        
        const maxPlayers = prompt('请输入最大玩家数 (2-10):', '4');
        if (!maxPlayers) return;
        
        const playersNum = parseInt(maxPlayers);
        if (isNaN(playersNum) || playersNum < 2 || playersNum > 10) {
            this.showNotification('玩家数必须是2-10之间的数字', 'warning');
            return;
        }
        
        this.processRoomCreation(roomName.trim(), playersNum);
    }

    // ============================
    // 游戏控制相关方法
    // ============================
    
    // 暂停/恢复游戏
    togglePause() {
        const pauseModal = document.getElementById('pause-screen');
        if (!pauseModal) return;
        
        if (pauseModal.classList.contains('hidden')) {
            // 暂停游戏
            pauseModal.classList.remove('hidden');
            pauseModal.style.display = 'flex';
            if (this.game && this.game.pause) {
                this.game.pause();
            }
            this.showNotification('游戏已暂停', 'info');
        } else {
            // 恢复游戏
            pauseModal.classList.add('hidden');
            pauseModal.style.display = 'none';
            if (this.game && this.game.resume) {
                this.game.resume();
            }
            this.showNotification('游戏已恢复', 'success');
        }
    }
    
    // 恢复游戏
    resumeGame() {
        console.log('恢复游戏...');
        this.togglePause(); // 调用现有的暂停/恢复方法
    }
    
    // 返回主菜单
    backToMenu() {
        console.log('返回主菜单...');
        
        // 停止游戏
        if (this.game && this.game.stop) {
            this.game.stop();
        }
        
        // 关闭WebSocket连接
        if (window.gameWebSocket && window.gameWebSocket.disconnect) {
            window.gameWebSocket.disconnect();
        }
        
        // 重置游戏状态
        this.game = null;
        this.room = null;
        
        // 恢复原始玩家ID
        if (this.originalPlayerId) {
            this.player.id = this.originalPlayerId;
            localStorage.setItem('mario_player', JSON.stringify(this.player));
        }
        
        // 显示主菜单
        this.showMenuScreen();
        
        this.showNotification('已返回主菜单', 'info');
    }
    
    // 切换房间
    changeRoom() {
        console.log('切换房间...');
        
        // 先返回菜单
        this.backToMenu();
        
        // 延迟显示房间列表
        setTimeout(() => {
            this.loadRooms();
        }, 500);
    }

    // ============================
    // 游戏引擎相关方法
    // ============================

    // 初始化游戏引擎
    initializeGameEngine() {
        console.log('初始化游戏引擎...');
        
        // 检查游戏画布
        const gameCanvas = document.getElementById('game-canvas');
        if (!gameCanvas) {
            console.error('游戏画布元素不存在');
            this.showNotification('游戏初始化失败：找不到画布', 'error');
            return;
        }
        
        // 确保画布有正确的像素尺寸
        if (gameCanvas.width === 0 || gameCanvas.height === 0) {
            gameCanvas.width = 800;
            gameCanvas.height = 600;
        }
        
        // 确保玩家数据存在
        if (!this.player) {
            console.warn('玩家数据不存在，使用默认玩家');
            this.player = {
                id: `player_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
                name: '默认玩家',
                role: 'mario',
                score: 0,
                sessionId: `session_${Date.now()}`
            };
        }
        
        // 初始化游戏引擎（如果尚未初始化）
        if (!this.game) {
            console.log('创建游戏引擎实例...');
            this.game = new GameEngine();
            
            // 等待引擎初始化
            setTimeout(() => {
                if (!this.game.isRunning) {
                    this.startGame();
                }
            }, 500);
        } else if (!this.game.isRunning) {
            // 如果游戏引擎已存在但未运行，启动它
            this.startGame();
        } else {
            console.log('游戏已经在运行中');
        }
    }

    startGame() {
        console.log('开始游戏...');
        
        if (!this.game) {
            console.error('游戏引擎未初始化');
            return;
        }
        
        // 检查游戏是否已经在运行
        if (this.game.isRunning) {
            console.log('游戏已经在运行中，跳过重复启动');
            return;
        }
        
        console.log('玩家信息:', this.player);
        
        // 确保画布大小正确
        this.resizeGameCanvas();
        
        // 启动游戏
        if (typeof this.game.startGame === 'function') {
            const playerName = this.player?.name || '玩家';
            console.log(`调用 game.startGame("${playerName}")`);
            this.game.startGame(playerName);
        } else {
            console.error('game.startGame 不是一个函数');
            console.log('游戏引擎对象:', this.game);
        }
        
        // 连接WebSocket
        this.connectWebSocket();
    }

    manualStartGame() {
        console.log('手动启动游戏...');
        
        if (!this.game || !this.player) return;
        
        // 添加当前玩家到游戏
        this.game.updatePlayerData({
                id: this.player.id,
                name: this.player.name,
                role: this.player.role || 'mario',
                x: 100,
                y: 390,
                status: 'stand--right',
                score: 0
            });
        
        // 如果游戏引擎有gameLoop方法，手动启动它
        if (typeof this.game.gameLoop === 'function') {
            console.log('手动启动游戏循环...');
            const startLoop = (timestamp) => {
                if (this.game && this.game.gameLoop) {
                    this.game.gameLoop(timestamp);
                    requestAnimationFrame(startLoop);
                }
            };
            requestAnimationFrame(startLoop);
        } else {
            console.error('无法手动启动游戏：没有找到gameLoop方法');
        }
    }

    // 修改 connectWebSocket 方法
connectWebSocket() {
    if (!window.gameWebSocket) {
        console.warn('WebSocket客户端未定义');
        return;
    }
    
    if (window.gameWebSocket.socket && window.gameWebSocket.socket.readyState === WebSocket.OPEN) {
        console.log('WebSocket已连接');
        return;
    }
    
    console.log('连接WebSocket...');
    window.gameWebSocket.connect();
    
    // 保存当前玩家ID以便同步
    const currentPlayer = this.player;
    if (!currentPlayer) return;
    
    // 监听WebSocket消息，更新玩家ID
    if (window.gameWebSocket.socket) {
        const originalOnMessage = window.gameWebSocket.socket.onmessage;
        
        window.gameWebSocket.socket.onmessage = (event) => {
            try {
                const data = JSON.parse(event.data);
                
                // 如果收到欢迎消息，更新玩家ID
                if (data.type === 'welcome' && data.playerId) {
                    console.log('WebSocket分配新玩家ID:', data.playerId);
                    
                    // 更新当前玩家ID
                    if (currentPlayer) {
                        const oldId = currentPlayer.id;
                        const newId = data.playerId;
                        currentPlayer.id = newId;
                        currentPlayer.name = data.playerName || currentPlayer.name;
                        
                        console.log(`玩家ID更新: ${oldId} -> ${newId}`);
                        
                        // 在游戏引擎中更新玩家ID映射
                        if (this.game && this.game.updatePlayerId) {
                            this.game.updatePlayerId(oldId, newId);
                        }
                        
                        // 保存到本地存储
                        localStorage.setItem('mario_player', JSON.stringify(currentPlayer));
                    }
                }
                
                // 调用原始onmessage处理程序
                if (originalOnMessage) {
                    originalOnMessage.call(window.gameWebSocket.socket, event);
                }
            } catch (error) {
                console.error('处理WebSocket消息失败:', error);
            }
        };
    }
}

    startMultiPlayer() {
        if (!this.player) {
            this.handleGuestLogin();
            return;
        }
        
        // 加入默认房间
        this.joinRoom('room-1');
    }

    async loadRooms() {
        try {
            // 显示加载状态
            const roomList = document.getElementById('room-list');
            if (roomList) {
                roomList.innerHTML = '<div class="loading-rooms">加载房间中...</div>';
            }
            
            if (!window.api || !window.api.getRooms) {
                console.warn('API不可用，显示默认房间');
                this.showDefaultRooms();
                return;
            }
            
            const response = await window.api.getRooms();
            
            if (response.success && response.data) {
                // 更新房间列表
                this.updateRoomList(response.data);
            } else {
                this.showDefaultRooms();
            }
        } catch (error) {
            console.error('加载房间失败:', error);
            this.showDefaultRooms();
        }
    }

    showDefaultRooms() {
        const rooms = [
            {
                roomId: 'room-1',
                roomName: '默认房间',
                currentPlayers: Math.floor(Math.random() * 5),
                maxPlayers: 10,
                isPlaying: false
            },
            {
                roomId: 'room-2',
                roomName: '竞技房间',
                currentPlayers: Math.floor(Math.random() * 3),
                maxPlayers: 4,
                isPlaying: false
            },
            {
                roomId: 'room-3',
                roomName: '新手房间',
                currentPlayers: Math.floor(Math.random() * 2),
                maxPlayers: 8,
                isPlaying: false
            }
        ];
        
        this.updateRoomList(rooms);
    }

    updateRoomList(rooms) {
        const roomList = document.getElementById('room-list');
        if (!roomList) return;
        
        roomList.innerHTML = '';
        
        if (!rooms || rooms.length === 0) {
            roomList.innerHTML = '<div class="no-rooms">暂无可用房间</div>';
            return;
        }
        
        rooms.forEach(room => {
            const roomItem = this.createRoomItem(room);
            roomList.appendChild(roomItem);
        });
    }

    createRoomItem(room) {
        const div = document.createElement('div');
        div.className = 'room-item';
        
        const isFull = room.currentPlayers >= room.maxPlayers;
        const canJoin = !room.isPlaying && !isFull;
        const statusClass = room.isPlaying ? 'playing' : (isFull ? 'full' : 'available');
        
        div.innerHTML = `
            <div class="room-info">
                <h4>${room.roomName || room.roomId}</h4>
                <p class="room-id">ID: ${room.roomId}</p>
                <div class="room-status-indicator ${statusClass}">
                    ${room.isPlaying ? '游戏中' : (isFull ? '已满' : '可加入')}
                </div>
            </div>
            <div class="room-stats">
                <div class="player-count">
                    <i class="player-icon"></i>
                    <span>${room.currentPlayers}/${room.maxPlayers}</span>
                </div>
                <button class="btn-join-room ${canJoin ? '' : 'disabled'}" 
                        data-room-id="${room.roomId}"
                        ${!canJoin ? 'disabled' : ''}>
                    ${canJoin ? '加入' : (isFull ? '已满' : '游戏中')}
                </button>
            </div>
        `;
        
        // 绑定加入房间事件
        const joinBtn = div.querySelector('.btn-join-room');
        if (joinBtn && canJoin) {
            joinBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.joinRoom(room.roomId);
            });
        }
        
        return div;
    }

    async joinRoom(roomId) {
        if (!this.player) {
            this.showNotification('请先登录', 'warning');
            return;
        }
        
        this.showNotification('正在加入房间...', 'info');
        
        try {
            if (!window.api || !window.api.joinRoom) {
                throw new Error('API不可用');
            }
            
            const response = await window.api.joinRoom(roomId, {
                playerId: this.player.id,
                playerName: this.player.name,
                role: this.player.role || 'mario',
                sessionId: this.player.sessionId || this.player.id
            });
            
            if (response.success) {
                const roomData = response.data || { roomId: roomId };
                this.room = roomData;
                this.player.roomId = roomId;
                
                // 保存更新后的玩家信息
                if (response.data && response.data.player) {
                    Object.assign(this.player, response.data.player);
                }
                
                localStorage.setItem('mario_player', JSON.stringify(this.player));
                
                this.showNotification(`加入房间 ${roomId} 成功！`, 'success');
                this.showGameScreen(roomData);
                
            } else {
                throw new Error(response.message || '加入房间失败');
            }
        } catch (error) {
            console.error('加入房间失败:', error);
            this.showNotification('加入房间失败: ' + error.message, 'error');
        }
    }

    showNotification(message, type = 'info') {
        try {
            if (window.uiController && window.uiController.showNotification) {
                window.uiController.showNotification(message, type);
            } else {
                // 简易通知
                console.log(`${type.toUpperCase()}: ${message}`);
                
                // 创建简易通知UI
                const notification = document.createElement('div');
                notification.className = `simple-notification ${type}`;
                notification.textContent = message;
                notification.style.cssText = `
                    position: fixed;
                    top: 20px;
                    right: 20px;
                    padding: 10px 20px;
                    background: ${type === 'error' ? '#ff6b6b' : 
                               type === 'success' ? '#1dd1a1' : 
                               type === 'warning' ? '#feca57' : '#54a0ff'};
                    color: white;
                    border-radius: 5px;
                    z-index: 10000;
                    max-width: 300px;
                    box-shadow: 0 2px 10px rgba(0,0,0,0.2);
                `;
                
                document.body.appendChild(notification);
                
                // 3秒后自动移除
                setTimeout(() => {
                    if (notification.parentNode) {
                        notification.parentNode.removeChild(notification);
                    }
                }, 3000);
            }
        } catch (error) {
            console.error('显示通知失败:', error);
        }
    }

    checkLocalStorage() {
        try {
            const savedPlayer = localStorage.getItem('mario_player');
            if (savedPlayer) {
                const parsed = JSON.parse(savedPlayer);
                if (parsed && parsed.name) {
                    this.player = parsed;
                    this.originalPlayerId = parsed.id;
                    console.log('加载保存的玩家数据:', this.player);
                }
            }
        } catch (error) {
            console.warn('加载本地存储失败:', error);
        }
    }
}

// 页面加载完成后启动游戏
window.addEventListener('DOMContentLoaded', () => {
    console.log('DOM加载完成，启动游戏...');
    
    // 检查必要API
    if (!window.WebSocket) {
        alert('您的浏览器不支持WebSocket，无法进行多人游戏。请使用最新版本的Chrome、Firefox或Edge浏览器。');
        return;
    }
    
    try {
        // 确保依赖已加载
        if (!window.api) {
            console.warn('API对象未加载，部分功能可能受限');
        }
        
        if (!window.GameEngine) {
            console.error('GameEngine未定义，游戏无法运行！');
            alert('游戏引擎加载失败，请刷新页面重试。');
            return;
        }
        
        window.gameApp = new MarioGame();
        console.log('游戏应用初始化完成:', window.gameApp);
        
    } catch (error) {
        console.error('创建游戏实例失败:', error);
        alert('游戏启动失败，请刷新页面重试。错误: ' + error.message);
    }
});

// 窗口大小变化时重新调整画布
window.addEventListener('resize', () => {
    if (window.gameApp && window.gameApp.currentScreen === 'game') {
        setTimeout(() => {
            window.gameApp.resizeGameCanvas();
        }, 100);
    }
});

// 页面加载完成后的初始调整
window.addEventListener('load', () => {
    setTimeout(() => {
        if (window.gameApp && window.gameApp.currentScreen === 'game') {
            window.gameApp.resizeGameCanvas();
        }
    }, 500);
});