/**
 * WebSocket客户端 - 连接后端
 */
class GameWebSocket {
    constructor() {
        this.socket = null;
        this.reconnectAttempts = 0;
        this.maxReconnectAttempts = 5;
        this.reconnectDelay = 1000;
        this.heartbeatInterval = null;
        this.lastPongTime = Date.now();
        
        this.initMessageHandlers();
    }

    getWebSocketURL() {
        // 获取当前玩家信息，添加到连接参数中
        const playerId = window.gameApp?.player?.id || '';
        const playerName = window.gameApp?.player?.name || '';
        return `ws://localhost:8080/ws/mario?playerId=${encodeURIComponent(playerId)}&playerName=${encodeURIComponent(playerName)}`;
    }

    connect() {
        if (this.socket && this.socket.readyState === WebSocket.OPEN) {
            console.log('WebSocket已经连接');
            return;
        }

        const wsUrl = this.getWebSocketURL();
        
        try {
            console.log('正在连接WebSocket:', wsUrl);
            this.socket = new WebSocket(wsUrl);
            
            this.socket.onopen = (event) => this.onOpen(event);
            this.socket.onmessage = (event) => this.onMessage(event);
            this.socket.onclose = (event) => this.onClose(event);
            this.socket.onerror = (event) => this.onError(event);
            
        } catch (error) {
            console.error('WebSocket连接失败:', error);
            this.handleReconnect();
        }
    }

    onOpen(event) {
        console.log('WebSocket连接成功');
        this.reconnectAttempts = 0;
        this.startHeartbeat();
        
        if (window.uiController) {
            window.uiController.updateServerStatus(true, '服务器连接成功');
            window.uiController.showNotification('连接服务器成功', 'success');
        }
        
        // 不需要发送欢迎消息，连接时已经包含玩家信息
    }

    onMessage(event) {
        try {
            const data = JSON.parse(event.data);
            this.handleMessage(data);
        } catch (error) {
            console.error('消息解析失败:', error);
        }
    }

    onClose(event) {
        console.log('WebSocket连接关闭:', event.code, event.reason);
        this.stopHeartbeat();
        
        if (window.uiController) {
            window.uiController.updateServerStatus(false, '服务器连接断开');
        }
        
        if (event.code !== 1000) {
            this.handleReconnect();
        }
    }

    onError(event) {
        console.error('WebSocket错误:', event);
        
        if (window.uiController) {
            window.uiController.showNotification('网络连接错误', 'error');
        }
    }

    initMessageHandlers() {
        this.handlers = {
            'welcome': (data) => this.handleWelcome(data),
            'game_state': (data) => this.handleGameState(data),
            'player_joined': (data) => this.handlePlayerJoined(data),
            'player_left': (data) => this.handlePlayerLeft(data),
            'chat': (data) => this.handleChatMessage(data),
            'player_move': (data) => this.handlePlayerMoved(data),
            'player_jump': (data) => this.handlePlayerJump(data),
            'room_info': (data) => this.handleRoomInfo(data),
            'error': (data) => this.handleError(data),
            'pong': () => this.lastPongTime = Date.now(),
            'player_update': (data) => this.handlePlayerUpdate(data)
        };
    }

    handleWelcome(data) {
        console.log('服务器欢迎消息:', JSON.stringify(data, null, 2));
        
        if (window.gameApp && data.playerId) {
            // 检查是否是新的ID
            if (window.gameApp.player.id !== data.playerId) {
                const oldId = window.gameApp.player.id;
                window.gameApp.player.id = data.playerId;
                window.gameApp.player.name = data.playerName || window.gameApp.player.name;
                
                console.log(`WebSocket玩家ID更新: ${oldId} -> ${data.playerId}`);
                
                // 在游戏引擎中更新玩家ID
                if (window.gameApp.game && window.gameApp.game.updatePlayerId) {
                    window.gameApp.game.updatePlayerId(oldId, data.playerId);
                }
            } else {
                console.log('玩家ID未变化');
            }
        }
        
        // 更新房间信息
        if (data.roomId) {
            window.gameApp.room = {
                id: data.roomId,
                name: data.roomName || data.roomId
            };
            
            if (window.uiController) {
                window.uiController.updateRoomInfo(data.roomId);
            }
        }
    }
    
    // 添加 gameState 消息处理器
    handleGameState(data) {
        console.log('游戏状态更新:', data);
        
        if (data.data && data.data.players) {
            const playersData = data.data.players;
            
            // 更新所有玩家
            Object.entries(playersData).forEach(([playerId, playerData]) => {
                // 如果是当前玩家自己，跳过更新（避免延迟冲突）
                if (playerId === window.gameApp?.player?.id) return;
                
                if (window.gameApp.game.updatePlayerData) {
                    window.gameApp.game.updatePlayerData({
                        id: playerId,
                        ...playerData
                    });
                }
            });
            
            // 更新玩家计数
            if (window.uiController) {
                const playerCount = Object.keys(playersData).length;
                window.uiController.updatePlayerCount(playerCount);
            }
        }
    }

    handlePlayerJoined(data) {
        console.log('玩家加入:', data);
        
        // 检查是否是有效的玩家加入消息
        if (!data.playerId || !data.playerName) {
            console.warn('无效的玩家加入消息:', data);
            return;
        }
        
        // 如果是当前玩家自己，跳过
        if (data.playerId === window.gameApp?.player?.id) return;
        
        // 在游戏中添加新玩家
        if (window.gameApp && window.gameApp.game) {
            window.gameApp.game.updatePlayerData({
                id: data.playerId,
                name: data.playerName,
                role: data.role || 'mario',
                x: data.x || 100,
                y: data.y || 355,
                status: 'stand--right',
                score: data.score || 0
            });
        }
        
        if (window.uiController) {
            window.uiController.addChatMessage('系统', `${data.playerName} 加入了游戏`, true);
        }
    }

    handlePlayerLeft(data) {
        console.log('玩家离开:', data);
        
        if (window.gameApp && window.gameApp.game && data.playerId) {
            if (window.gameApp.game.removePlayer) {
                window.gameApp.game.removePlayer(data.playerId);
            }
        }
        
        if (window.uiController) {
            window.uiController.addChatMessage('系统', `${data.playerName || '玩家'} 离开了游戏`, true);
        }
    }

    handleChatMessage(data) {
        console.log('聊天消息:', data);
        
        if (data.message && data.sender && window.uiController) {
            window.uiController.addChatMessage(data.sender, data.message);
        }
    }

    handlePlayerMoved(data) {
        console.log('玩家移动:', data);
        
        if (data.playerId && window.gameApp && window.gameApp.game) {
            // 只更新其他玩家的移动，不更新自己的（避免延迟冲突）
            if (data.playerId !== window.gameApp.player?.id) {
                if (window.gameApp.game.updatePlayerData) {
                    window.gameApp.game.updatePlayerData({
                        id: data.playerId,
                        x: data.x,
                        y: data.y,
                        status: data.status || 'stand--right'
                    });
                }
            }
        }
    }

    handlePlayerJump(data) {
        console.log('玩家跳跃:', data);
        
        if (data.playerId && window.gameApp && window.gameApp.game) {
            // 只更新其他玩家的跳跃，不更新自己的
            if (data.playerId !== window.gameApp.player?.id) {
                if (window.gameApp.game.jumpPlayer) {
                    window.gameApp.game.jumpPlayer(data.playerId);
                }
            }
        }
    }

    handlePlayerUpdate(data) {
        console.log('玩家更新:', data);
        
        if (data.playerId && window.gameApp && window.gameApp.game) {
            // 只更新其他玩家
            if (data.playerId !== window.gameApp.player?.id) {
                if (window.gameApp.game.updatePlayerData) {
                    window.gameApp.game.updatePlayerData({
                        id: data.playerId,
                        x: data.x,
                        y: data.y,
                        status: data.status,
                        role: data.role
                    });
                }
            }
        }
    }

    handleRoomInfo(data) {
        console.log('房间信息:', data);
        
        if (data.roomId && window.gameApp) {
            window.gameApp.room = data;
            
            if (window.uiController) {
                window.uiController.updateRoomInfo(data.roomId, data.roomName);
            }
        }
    }

    handleError(data) {
        console.error('服务器错误:', data.message);
        
        if (window.uiController) {
            window.uiController.showNotification(`错误: ${data.message}`, 'error');
        }
    }

    handleMessage(data) {
        const type = data.type;
        const handler = this.handlers[type];
        
        if (handler) {
            handler(data);
        } else {
            console.log('未处理的消息类型:', type, data);
        }
    }

    send(data) {
        if (this.isConnected()) {
            try {
                this.socket.send(JSON.stringify(data));
                return true;
            } catch (error) {
                console.error('发送消息失败:', error);
                return false;
            }
        } else {
            console.warn('WebSocket未连接，消息发送失败:', data);
            return false;
        }
    }

    isConnected() {
        return this.socket && this.socket.readyState === WebSocket.OPEN;
    }

    sendPlayerMove(direction) {
        if (!window.gameApp || !window.gameApp.player) return false;
        
        return this.send({
            type: 'player_move',
            direction: direction,
            playerId: window.gameApp.player.id,
            playerName: window.gameApp.player.name
        });
    }

    sendPlayerJump() {
        if (!window.gameApp || !window.gameApp.player) return false;
        
        return this.send({
            type: 'player_jump',
            playerId: window.gameApp.player.id,
            playerName: window.gameApp.player.name
        });
    }

    sendPlayerUpdate(playerData) {
        if (!window.gameApp || !window.gameApp.player) return false;
        
        return this.send({
            type: 'player_update',
            playerId: window.gameApp.player.id,
            playerName: window.gameApp.player.name,
            x: playerData.x,
            y: playerData.y,
            status: playerData.status,
            role: window.gameApp.player.role || 'mario'
        });
    }

    sendChatMessage(message) {
        if (!window.gameApp || !window.gameApp.player) return false;
        
        return this.send({
            type: 'chat',
            message: message,
            playerId: window.gameApp.player.id,
            playerName: window.gameApp.player.name
        });
    }

    sendChangeRole(role) {
        if (!window.gameApp || !window.gameApp.player) return false;
        
        return this.send({
            type: 'change_role',
            role: role,
            playerId: window.gameApp.player.id
        });
    }

    sendSwitchRoom(targetRoomId) {
        if (!window.gameApp || !window.gameApp.player) return false;
        
        return this.send({
            type: 'switch_room',
            targetRoomId: targetRoomId,
            playerId: window.gameApp.player.id
        });
    }

    startHeartbeat() {
        this.stopHeartbeat();
        
        this.heartbeatInterval = setInterval(() => {
            if (this.isConnected()) {
                this.send({ type: 'ping' });
                
                if (Date.now() - this.lastPongTime > 60000) {
                    console.warn('心跳超时，重新连接...');
                    this.reconnect();
                }
            }
        }, 30000);
    }

    stopHeartbeat() {
        if (this.heartbeatInterval) {
            clearInterval(this.heartbeatInterval);
            this.heartbeatInterval = null;
        }
    }

    handleReconnect() {
        if (this.reconnectAttempts < this.maxReconnectAttempts) {
            this.reconnectAttempts++;
            const delay = this.reconnectDelay * Math.pow(2, this.reconnectAttempts - 1);
            
            console.log(`尝试重新连接 (${this.reconnectAttempts}/${this.maxReconnectAttempts})，等待 ${delay}ms...`);
            
            if (window.uiController) {
                window.uiController.showNotification(`连接断开，正在重连... (${this.reconnectAttempts}/${this.maxReconnectAttempts})`, 'warning');
            }
            
            setTimeout(() => {
                this.connect();
            }, delay);
        } else {
            console.error('达到最大重连次数，连接失败');
            
            if (window.uiController) {
                window.uiController.showNotification('连接服务器失败，请刷新页面重试', 'error');
            }
        }
    }

    reconnect() {
        this.disconnect();
        this.connect();
    }

    disconnect() {
        this.stopHeartbeat();
        
        if (this.socket) {
            this.socket.close();
            this.socket = null;
        }
    }
}

// 创建全局WebSocket实例
window.gameWebSocket = new GameWebSocket();